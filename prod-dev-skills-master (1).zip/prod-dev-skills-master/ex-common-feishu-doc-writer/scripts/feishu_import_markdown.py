#!/usr/bin/env python3
import argparse
import json
import os
import re
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple


BASE_URL = "https://open.feishu.cn/open-apis"

# Create SSL context that skips verification for self-signed certificates
_ssl_context = ssl.create_default_context()
_ssl_context.check_hostname = False
_ssl_context.verify_mode = ssl.CERT_NONE


@dataclass
class MermaidBlock:
    code: str
    prev_anchor: str
    next_anchor: str


def normalize_text(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"\s+", " ", text.strip())
    return text


def cleanup_anchor(line: str) -> str:
    line = line.strip()
    line = re.sub(r"^#{1,6}\s+", "", line)
    line = re.sub(r"^>\s*", "", line)
    line = re.sub(r"^[-*+]\s+", "", line)
    line = re.sub(r"^\d+\.\s+", "", line)
    line = re.sub(r"`+", "", line)
    return normalize_text(line)


def extract_title(markdown: str, fallback: str) -> str:
    for line in markdown.splitlines():
        match = re.match(r"^#\s+(.+?)\s*$", line)
        if match:
            return match.group(1).strip()
    return fallback


def parse_mermaid_blocks(markdown: str) -> List[MermaidBlock]:
    lines = markdown.splitlines()
    mermaid_blocks: List[MermaidBlock] = []
    i = 0
    while i < len(lines):
        if lines[i].strip().startswith("```mermaid"):
            start = i
            i += 1
            code_lines: List[str] = []
            while i < len(lines) and not lines[i].strip().startswith("```"):
                code_lines.append(lines[i])
                i += 1
            end = i
            prev_anchor = ""
            next_anchor = ""
            for j in range(start - 1, -1, -1):
                candidate = cleanup_anchor(lines[j])
                if candidate:
                    prev_anchor = candidate
                    break
            for j in range(end + 1, len(lines)):
                candidate = cleanup_anchor(lines[j])
                if candidate:
                    next_anchor = candidate
                    break
            mermaid_blocks.append(
                MermaidBlock(
                    code="\n".join(code_lines).strip("\n"),
                    prev_anchor=prev_anchor,
                    next_anchor=next_anchor,
                )
            )
        i += 1
    return mermaid_blocks


def build_multipart_form(fields: Dict[str, str], file_field: str, file_path: Path, content_type: str) -> Tuple[bytes, str]:
    boundary = f"----CodexBoundary{uuid.uuid4().hex}"
    parts: List[bytes] = []
    for name, value in fields.items():
        parts.append(
            (
                f"--{boundary}\r\n"
                f'Content-Disposition: form-data; name="{name}"\r\n\r\n'
                f"{value}\r\n"
            ).encode("utf-8")
        )
    parts.append(
        (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="{file_field}"; filename="{file_path.name}"\r\n'
            f"Content-Type: {content_type}\r\n\r\n"
        ).encode("utf-8")
    )
    parts.append(file_path.read_bytes())
    parts.append(f"\r\n--{boundary}--\r\n".encode("utf-8"))
    return b"".join(parts), boundary


class FeishuClient:
    def __init__(self, app_id: str, app_secret: str):
        self.app_id = app_id
        self.app_secret = app_secret
        self.token: Optional[str] = None

    def _request(
        self,
        method: str,
        path: str,
        payload: Optional[dict] = None,
        headers: Optional[Dict[str, str]] = None,
        raw_body: Optional[bytes] = None,
    ) -> dict:
        url = f"{BASE_URL}{path}"
        request_headers = {"Content-Type": "application/json; charset=utf-8"}
        if headers:
            request_headers.update(headers)
        if self.token:
            request_headers.setdefault("Authorization", f"Bearer {self.token}")
        data = raw_body if raw_body is not None else (
            json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload is not None else None
        )
        req = urllib.request.Request(url, data=data, headers=request_headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=120, context=_ssl_context) as resp:
                body = resp.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"{method} {path} failed: HTTP {exc.code}: {detail}") from exc
        parsed = json.loads(body)
        if parsed.get("code") != 0:
            raise RuntimeError(f"{method} {path} failed: {body}")
        return parsed

    def authenticate(self) -> None:
        resp = self._request(
            "POST",
            "/auth/v3/tenant_access_token/internal",
            payload={"app_id": self.app_id, "app_secret": self.app_secret},
            headers={"Content-Type": "application/json; charset=utf-8"},
        )
        self.token = resp["tenant_access_token"]

    def upload_markdown(self, file_path: Path) -> str:
        body, boundary = build_multipart_form(
            fields={
                "file_name": file_path.name,
                "parent_type": "explorer",
                "size": str(file_path.stat().st_size),
            },
            file_field="file",
            file_path=file_path,
            content_type="text/markdown",
        )
        resp = self._request(
            "POST",
            "/drive/v1/files/upload_all",
            headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
            raw_body=body,
        )
        return resp["data"]["file_token"]

    def create_import_task(self, file_token: str, title: str, folder_token: str) -> str:
        payload = {
            "file_token": file_token,
            "type": "docx",
            "file_extension": "md",
            "file_name": title,
            "point": {"mount_key": folder_token, "mount_type": 1},
        }
        resp = self._request("POST", "/drive/v1/import_tasks", payload=payload)
        return resp["data"]["ticket"]

    def wait_for_import(self, ticket: str) -> dict:
        last: Optional[dict] = None
        for _ in range(30):
            last = self._request("GET", f"/drive/v1/import_tasks/{ticket}")
            result = (last.get("data") or {}).get("result") or (last.get("data") or {}).get("job_result") or {}
            if result.get("job_status") == 0:
                return result
            time.sleep(2)
        raise RuntimeError(f"Import task did not complete in time: {json.dumps(last, ensure_ascii=False)}")

    def list_blocks(self, document_id: str) -> List[dict]:
        items: List[dict] = []
        page_token = ""
        while True:
            query = urllib.parse.urlencode(
                {
                    "document_revision_id": -1,
                    "page_size": 500,
                    **({"page_token": page_token} if page_token else {}),
                }
            )
            resp = self._request("GET", f"/docx/v1/documents/{document_id}/blocks?{query}")
            data = resp["data"]
            items.extend(data.get("items", []))
            if not data.get("has_more"):
                return items
            page_token = data["page_token"]

    def delete_child_range(self, document_id: str, parent_block_id: str, start_index: int, end_index: int) -> None:
        query = urllib.parse.urlencode({"document_revision_id": -1})
        self._request(
            "DELETE",
            f"/docx/v1/documents/{document_id}/blocks/{parent_block_id}/children/batch_delete?{query}",
            payload={"start_index": start_index, "end_index": end_index},
        )

    def insert_mermaid_addon(self, document_id: str, parent_block_id: str, index: int, mermaid_code: str) -> str:
        query = urllib.parse.urlencode({"document_revision_id": -1})
        record = json.dumps(
            {
                "data": mermaid_code,
                "theme": "default",
                "view": "codeChart",
            },
            ensure_ascii=False,
        )
        resp = self._request(
            "POST",
            f"/docx/v1/documents/{document_id}/blocks/{parent_block_id}/children?{query}",
            payload={
                "children": [
                    {
                        "block_type": 40,
                        "add_ons": {
                            "component_id": "",
                            "component_type_id": "blk_631fefbbae02400430b8f9f4",
                            "record": record,
                        },
                    }
                ],
                "index": index,
                "client_token": str(uuid.uuid4()),
            },
        )
        return resp["data"]["children"][0]["block_id"]


def block_text(block: dict) -> str:
    for key in ("text", "heading1", "heading2", "heading3", "heading4", "heading5", "heading6", "bullet", "ordered", "quote", "code"):
        if key in block:
            elements = block[key].get("elements", [])
            chunks: List[str] = []
            for element in elements:
                if "text_run" in element:
                    chunks.append(element["text_run"].get("content", ""))
            return "".join(chunks)
    return ""


def find_replacements(source_mermaids: List[MermaidBlock], root_children: List[str], blocks_by_id: Dict[str, dict]) -> List[Tuple[int, MermaidBlock]]:
    candidates = []
    for root_index, block_id in enumerate(root_children):
        block = blocks_by_id.get(block_id)
        if not block or block.get("block_type") != 14:
            continue
        candidates.append(
            {
                "root_index": root_index,
                "block_id": block_id,
                "code": normalize_text(block_text(block)),
            }
        )

    matches: List[Tuple[int, MermaidBlock]] = []
    used: set[str] = set()
    min_index = -1
    for mermaid in source_mermaids:
        target_code = normalize_text(mermaid.code)
        exact = [c for c in candidates if c["block_id"] not in used and c["root_index"] > min_index and c["code"] == target_code]
        if not exact:
            raise RuntimeError(f"Could not locate imported code block for Mermaid snippet starting with: {mermaid.code[:80]!r}")

        def anchor_score(candidate: dict) -> Tuple[int, int]:
            idx = candidate["root_index"]
            prev_text = normalize_text(block_text(blocks_by_id[root_children[idx - 1]]) if idx - 1 >= 0 else "")
            next_text = normalize_text(block_text(blocks_by_id[root_children[idx + 1]]) if idx + 1 < len(root_children) else "")
            score = 0
            if mermaid.prev_anchor and prev_text and (mermaid.prev_anchor in prev_text or prev_text in mermaid.prev_anchor):
                score += 2
            if mermaid.next_anchor and next_text and (mermaid.next_anchor in next_text or next_text in mermaid.next_anchor):
                score += 2
            return (score, -idx)

        chosen = max(exact, key=anchor_score)
        used.add(chosen["block_id"])
        min_index = chosen["root_index"]
        matches.append((chosen["root_index"], mermaid))

    return matches


def import_markdown_with_mermaid(file_path: Path, title: str, folder_token: str) -> dict:
    app_id = os.getenv("FEISHU_APP_ID")
    app_secret = os.getenv("FEISHU_APP_SECRET")
    if not app_id or not app_secret:
        raise RuntimeError("FEISHU_APP_ID and FEISHU_APP_SECRET are required")

    markdown = file_path.read_text(encoding="utf-8")
    mermaids = parse_mermaid_blocks(markdown)

    client = FeishuClient(app_id, app_secret)
    client.authenticate()
    file_token = client.upload_markdown(file_path)
    ticket = client.create_import_task(file_token, title, folder_token)
    import_result = client.wait_for_import(ticket)
    document_id = import_result["token"]
    url = import_result["url"]

    if not mermaids:
        return {"document_id": document_id, "url": url, "replaced_mermaids": 0}

    blocks = client.list_blocks(document_id)
    if not blocks:
        raise RuntimeError("Imported document returned no blocks")
    page_block = next((block for block in blocks if block.get("block_type") == 1 and block.get("block_id") == document_id), None)
    if not page_block:
        raise RuntimeError("Could not locate root page block in imported document")
    root_children = page_block.get("children", [])
    blocks_by_id = {block["block_id"]: block for block in blocks}
    replacements = find_replacements(mermaids, root_children, blocks_by_id)

    for root_index, mermaid in sorted(replacements, key=lambda item: item[0], reverse=True):
        client.delete_child_range(document_id, document_id, root_index, root_index + 1)
        client.insert_mermaid_addon(document_id, document_id, root_index, mermaid.code)

    return {"document_id": document_id, "url": url, "replaced_mermaids": len(replacements)}


def main() -> int:
    parser = argparse.ArgumentParser(description="Import markdown to Feishu docx and replace Mermaid code blocks with Mermaid add-on blocks.")
    parser.add_argument("markdown_file", help="Local markdown file path")
    parser.add_argument("--title", help="Feishu document title. Defaults to first H1 or file stem.")
    parser.add_argument("--folder-token", default="", help="Target Feishu folder token. Defaults to app root.")
    args = parser.parse_args()

    file_path = Path(args.markdown_file)
    if not file_path.exists():
        print(f"File not found: {file_path}", file=sys.stderr)
        return 1

    markdown = file_path.read_text(encoding="utf-8")
    title = args.title or extract_title(markdown, file_path.stem)
    result = import_markdown_with_mermaid(file_path, title, args.folder_token)
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

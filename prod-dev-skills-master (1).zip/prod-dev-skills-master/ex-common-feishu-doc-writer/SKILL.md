---
name: ex-common-feishu-doc-writer
description: 将本地 Markdown 或文本文件写入飞书知识空间。通过飞书开放平台 API 在指定知识空间下创建 docx 节点，导入 Markdown 内容；若文档包含 Mermaid，则在导入后替换为飞书 Mermaid 文本绘图块。触发场景：用户提到写入飞书文档、创建飞书文档、同步到飞书、发布到飞书、上传到飞书文档。
---

# 写入飞书文档

读取本地文档内容，通过飞书开放平台 API 以登录用户身份在指定知识空间下创建 docx 节点，导入 Markdown 内容。

对于普通 Markdown，优先使用 Markdown 导入。

对于包含 Mermaid 的 Markdown，必须使用"两阶段导入"：

1. 先通过 `drive/v1/import_tasks` 导入整篇 Markdown
2. 再扫描导入后的文档块，把 Mermaid 对应的普通代码块替换成飞书 Mermaid 文本绘图块（`block_type = 40`）

不要再使用"直接结构化写块"作为默认方案。它适合简单文本，但对 Markdown 还原度和 Mermaid 支持都不如导入链路。

## 前置条件

| 条件 | 说明 |
|------|------|
| 飞书用户账号 | 需要 `FEISHU_ACCOUNT`（用户邮箱），用于获取 `user_access_token` |
| 知识空间权限 | 用户需为知识空间成员，且对父节点有编辑权限 |

## 用户必传参数

| 参数 | 说明 | 获取方式 |
|------|------|---------|
| `space_id` | 知识空间 ID | 知识库设置页面地址栏中的数字，或通过 API 获取 |
| `parent_node_token` | 父节点 token | 知识空间中目标父节点的 token，如 `wikcnXXXX` |

## 支持的本地文件格式

| 格式 | 说明 |
|------|------|
| `.md` | 默认格式。优先走 Markdown 导入 |
| `.txt` | 可直接按纯文本导入或转换为简单 Markdown |

## Mermaid 处理原则

### 结论

1. Markdown 导入会把 ```` ```mermaid ```` 变成普通代码块，丢失语言标签
2. 飞书公开 API 支持直接创建 Mermaid 文本绘图块：
   - `block_type = 40`
   - `add_ons.component_type_id = "blk_631fefbbae02400430b8f9f4"`
   - `add_ons.record` 中保存 Mermaid 源码
3. 公开 API 目前不支持直接 `PATCH` 更新这个 Mermaid 块
4. 如需更新 Mermaid，采用"删除旧块，再在同一位置重建新块"的方式

### 写入策略

遇到 Mermaid 时，最终目标块必须是 `block_type=40` 的 Mermaid 文本绘图块，而不是：

- 普通代码块 `block_type=14`
- whiteboard `block_type=43`

whiteboard 仅作为历史兼容或探测手段，不作为当前 skill 的默认输出。

## 执行流程

### 第1步：确认输入

1. 获取本地文件路径
2. 读取文件内容
3. 识别是否包含 ```` ```mermaid ```` 代码块
4. 获取用户必传参数：
   - **space_id**（必需）：知识空间 ID
   - **parent_node_token**（必需）：父节点 token
5. 确认文档标题
   - 默认优先取首个 H1
   - 否则使用文件名

### 第2步：获取访问凭证

使用登录用户身份获取 `user_access_token`。

凭证来源优先级：

1. 环境变量 `FEISHU_ACCOUNT`（用户邮箱）
2. 项目 `.env` 中的 `FEISHU_ACCOUNT`
3. 向用户询问

通过飞书 OAuth 授权流程获取 `user_access_token`，后续所有 API 调用均使用 `user_access_token` 作为身份凭证。

### 第3步：在知识空间中创建 docx 节点

调用知识空间创建节点 API：

```http
POST https://open.feishu.cn/open-apis/wiki/v2/spaces/{space_id}/nodes
Authorization: Bearer {user_access_token}
Content-Type: application/json

{
  "obj_type": "docx",
  "node_type": "origin",
  "parent_node_token": "{parent_node_token}",
  "title": "{title}"
}
```

**参数说明**：

| 参数 | 必填 | 说明 |
|------|------|------|
| `obj_type` | 是 | 文档类型，固定为 `docx`（新版文档） |
| `node_type` | 是 | 节点类型，固定为 `origin`（创建全新文档节点） |
| `parent_node_token` | 是 | 父节点 token，文档将创建在此节点下 |
| `title` | 否 | 文档标题，不传则使用默认标题 |

**响应**：

从响应中获取：
- `data.node.token`：知识空间节点 token（wiki token）
- `data.node.obj_token`：文档实际 token（用于后续文档内容操作）

### 第4步：上传 Markdown 源文件

优先上传源文件，而不是手写块：

```http
POST https://open.feishu.cn/open-apis/drive/v1/files/upload_all
Authorization: Bearer {user_access_token}
Content-Type: multipart/form-data
```

关键字段：

- `file_name`
- `parent_type = explorer`
- `size`
- `file`

### 第5步：创建导入任务

调用：

```http
POST https://open.feishu.cn/open-apis/drive/v1/import_tasks
Authorization: Bearer {user_access_token}
Content-Type: application/json

{
  "file_token": "{file_token}",
  "type": "docx",
  "file_extension": "md",
  "file_name": "{title}",
  "point": {
    "mount_key": "{obj_token}",
    "mount_type": 1
  }
}
```

然后轮询：

```http
GET https://open.feishu.cn/open-apis/drive/v1/import_tasks/{ticket}
Authorization: Bearer {user_access_token}
```

从结果中获取：

- `result.token` 作为 `document_id`
- `result.url` 作为最终文档 URL

### 第6步：若存在 Mermaid，执行 Mermaid 后处理

这是本 skill 的重点。

#### 6.1 先在本地解析 Markdown

必须在导入前记录每个 Mermaid fence：

- Mermaid 源码
- 在源文档中的顺序
- 前后锚点文本（例如相邻段落、标题）

原因：

Markdown 导入后，飞书只会保留普通代码块内容，不会保留 `mermaid` 语言标签，不能仅靠导入后的块结构判断哪个代码块原本是 Mermaid。

#### 6.2 读取导入后的文档块

调用：

```http
GET https://open.feishu.cn/open-apis/docx/v1/documents/{document_id}/blocks?document_revision_id=-1&page_size=500
Authorization: Bearer {user_access_token}
```

使用块列表做两件事：

1. 找到根页面块及其 children 顺序
2. 找到所有普通代码块 `block_type = 14`

#### 6.3 定位 Mermaid 对应的代码块

优先策略：

1. 按源码文本精确匹配代码块内容
2. 用前后锚点辅助消歧
3. 按文档顺序单调匹配，避免重复命中

如果无法唯一定位，停止并报告用户，不要盲删。

#### 6.4 删除旧代码块

调用：

```http
DELETE https://open.feishu.cn/open-apis/docx/v1/documents/{document_id}/blocks/{parent_block_id}/children/batch_delete?document_revision_id=-1
Authorization: Bearer {user_access_token}
Content-Type: application/json

{
  "start_index": {i},
  "end_index": {i+1}
}
```

通常 `parent_block_id` 就是根页面块 `document_id`。

#### 6.5 在同一位置重建 Mermaid 文本绘图块

调用：

```http
POST https://open.feishu.cn/open-apis/docx/v1/documents/{document_id}/blocks/{parent_block_id}/children?document_revision_id=-1
Authorization: Bearer {user_access_token}
Content-Type: application/json

{
  "children": [
    {
      "block_type": 40,
      "add_ons": {
        "component_id": "",
        "component_type_id": "blk_631fefbbae02400430b8f9f4",
        "record": "{\"data\":\"graph TD\\nA-->B\",\"theme\":\"default\",\"view\":\"codeChart\"}"
      }
    }
  ],
  "index": {i}
}
```

其中 `record` 为 JSON 字符串，至少包含：

- `data`: Mermaid 源码
- `theme`: 通常 `default`
- `view`: 通常 `codeChart`

### 第7步：返回结果

1. 返回文档 URL
2. 告知用户 Mermaid 已替换为飞书 Mermaid 文本绘图块
3. 如果存在失败的 Mermaid 替换，明确报告失败数量和位置

## 推荐实现

若当前仓库已经存在可复用脚本，优先复用。

例如在当前 skill 目录下，若存在：

- `scripts/feishu_import_markdown.py`

则优先使用该类脚本，而不是临时拼接一次性命令。

## 错误处理

| 错误场景 | 处理方式 |
|----------|---------|
| 本地文件不存在 | 提示用户确认路径 |
| 用户账号未配置 | 提示配置 `FEISHU_ACCOUNT` |
| space_id 或 parent_node_token 缺失 | 提示用户必须提供知识空间 ID 和父节点 token |
| 知识空间权限不足 | 提示用户确认是否为知识空间成员，且对父节点有编辑权限 |
| 节点创建失败 | 报告 API 返回的错误码和错误信息 |
| 文件上传失败 | 报告 `upload_all` 返回的错误 |
| 导入任务失败 | 报告 `import_tasks` 的错误信息 |
| Mermaid 定位失败 | 停止替换并明确指出是哪个 Mermaid 片段未定位成功 |
| Mermaid add-on 创建失败 | 保留原代码块，并报告失败 |
| API 限流 | 等待 1 秒后重试，最多 3 次 |

## 已知限制

| 限制 | 说明 |
|------|------|
| Mermaid block 不能直接 PATCH 更新 | 公开 API 下应使用"删除 + 原位重建" |
| 导入后的代码块不保留 `mermaid` 标签 | 必须结合源 Markdown 做定位 |
| 复杂表格/嵌套列表仍可能有损 | 这是 Markdown 导入本身的限制 |
| 图片引用不会自动变成飞书图片资源 | 需额外上传与绑定 |
| 知识空间节点数量限制 | 单个知识空间总节点数不超过 40 万，单层子节点数不超过 2000 |

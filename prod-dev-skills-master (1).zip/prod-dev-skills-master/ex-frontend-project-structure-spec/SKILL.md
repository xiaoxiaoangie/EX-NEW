---
name: ex-frontend-project-structure-spec
description: 前端 Vue 3 + TypeScript 工程结构规范，定义目录划分、文件命名和模块组织。此skill不由用户直接触发，由其他职责skill触发加载。
---

# 前端工程结构规范

基于 ex-merchant-portal 实际工程总结，所有新增代码必须遵循本规范。

## 目录结构

```
{工程名}/
├── README.md
├── package.json / tsconfig.json / vite.config.ts / uno.config.ts / eslint.config.mjs
├── .env.development / .env.production
│
├── docs/
│   └── {domain}/                                # 按业务域组织文档
│       ├── prototypes/
│       │   └── {页面名}.html                     #【AI生成/维护，人确认】页面原型
│       ├── requirements/
│       │   └── {jira}-{需求简述}/
│       │       ├── {jira}-prd-*.md              #【人提供】需求描述
│       │       ├── {jira}-techdesign-*.md       #【AI生成】技术方案
│       │       ├── {jira}-taskbreakdown-*.md    #【AI生成】任务拆解
│       │       ├── {jira}-testcase-*.md         #【AI生成】测试用例
│       │       ├── {jira}-integrationtest-*.md  #【AI生成】联调测试报告
│       │       ├── {jira}-usertest-*.md         #【AI生成】用户测试报告
│       │       ├── {jira}-changelog-*.md        #【AI生成】变更记录
│       │       ├── unit-test/*.spec.ts          #【AI生成】单元测试
│       │       ├── e2e-test/{page-name}.spec.ts #【AI生成】E2E测试
│       │       └── {其他文档}.md                 #【AI生成】其他未明确指定过的文档
│       ├── designs/
│       │   ├── full-technical-design.md         #【AI生成，人确认】技术方案全景
│       │   └── full-testcases.md               #【AI生成，人确认】测试用例全景，增量累积
│       └── backend-apis/
│           └── {服务名}-api.md                   #【人维护】后端接口清单
│
├── public/
│
└── src/
    ├── api/                    # API 请求模块（平铺，按业务域命名，kebab-case）
    ├── assets/
    │   ├── icons/system/       # 字体图标（iconfont）
    │   ├── img/                # 图片资源
    │   └── styles/             # 全局 SCSS（variables.scss / mixins.scss / overrides/）
    ├── components/
    │   ├── core/               # 通用组件（base/ forms/ tables/ charts/ layouts/）
    │   └── business/           # 业务复用组件
    ├── composables/            # 组合式函数（use 前缀，camelCase）
    ├── config/                 # 配置文件
    ├── directives/             # Vue 自定义指令（auth.ts / roles.ts / index.ts）
    ├── enums/                  # 枚举（camelCase，如 appEnum.ts）
    ├── locales/                # 国际化（langs/zh.json / en.json）
    ├── router/
    │   ├── index.ts            # 路由实例
    │   ├── routes/             # staticRoutes.ts / asyncRoutes.ts（不按域拆分）
    │   ├── guards/             # beforeEach.ts / afterEach.ts
    │   ├── menus/              # microMenus.ts
    │   └── utils/              # menuToRouter.ts / registerRoutes.ts
    ├── store/
    │   ├── index.ts            # Pinia 初始化（含持久化插件）
    │   └── modules/            # user / menu / setting / worktab / config / {domain}
    ├── types/                  # TypeScript 类型（api/ router/ store/ component/）
    ├── typings/                # 全局类型声明（api.d.ts / form.d.ts / http.d.ts）
    ├── utils/                  # 工具函数（http/ permission/ storage/ navigation/ dataprocess/ micro/）
    ├── views/                  # 页面组件（与路由一一对应）
    │   └── {domain}/{page-name}/
    │       ├── index.vue       # 页面主组件
    │       ├── style.scss
    │       └── components/     # 页面私有组件（PascalCase 文件名）
    ├── mock/                   # Mock 数据（仅开发环境）
    ├── App.vue
    └── main.ts
```

## 命名规范

### 文件命名

| 类型 | 命名规则 | 示例 |
|------|---------|------|
| 页面目录 | kebab-case | `roles-permissions/` |
| 页面主组件 | `index.vue`（固定） | `views/settings/profile/index.vue` |
| 页面私有子组件 | PascalCase | `components/RoleTable.vue` |
| 通用/业务组件目录 | kebab-case | `art-table/`、`ex-otp-input/` |
| 通用/业务组件主文件 | `index.vue`（固定） | `components/core/tables/art-table/index.vue` |
| 通用/业务组件子组件 | PascalCase | `widget/BasicSettings.vue` |
| composable | camelCase，use 前缀 | `useAuth.ts` |
| store 模块 | camelCase | `user.ts`（导出 `useUserStore`） |
| API 模块 | kebab-case | `system-manage.ts` |
| 枚举文件 | camelCase | `appEnum.ts` |

### 组件命名前缀

| 类型 | 前缀 | 示例 |
|------|------|------|
| 通用组件（目录） | `art-` | `art-table`、`art-settings-panel` |
| 业务组件（目录） | `ex-` | `ex-otp-input`、`ex-logo` |

### 路由命名

| 类型 | 命名规则 | 示例 |
|------|----------|------|
| 路由 path | kebab-case | `/roles-permissions` |
| 路由 name | PascalCase | `'RolesPermissions'` |

## 路由 meta 常用字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `title` | `string` | i18n key，如 `'menus.user.list'` |
| `icon` | `string` | UnoCSS 图标类，如 `'i-ri-user-line'` |
| `isHide` | `boolean` | 是否在侧边栏隐藏 |
| `keepAlive` | `boolean` | 是否缓存页面 |
| `permissions` | `string[]` | 所需权限码 |
| `isFullPage` | `boolean` | 是否全屏页面 |
| `sort` | `number` | 菜单排序 |

## 路径别名

| 别名 | 解析路径 |
|------|---------|
| `@` | `src/` |
| `@views` | `src/views/` |
| `@utils` | `src/utils/` |
| `@stores` | `src/store/` |
| `@styles` | `src/assets/styles/` |
| `@icons` | `src/assets/icons/` |
| `@imgs` | `src/assets/img/` |

## 组件目录规则

**单文件组件：** 直接放 `index.vue`。

**复杂组件：** 使用目录封装，子组件放 `widget/`（通用组件）或 `components/`（页面私有）：
```
components/core/layouts/art-settings-panel/
├── index.vue
├── style.scss
├── composables/useSettingsState.ts
└── widget/BasicSettings.vue
```

**页面私有组件提升规则：** 当私有组件被第二个页面引用时，提升到 `components/business/`。

## API 模块组织规则

- API 文件平铺在 `src/api/`，按业务域命名（kebab-case）
- URL 前缀格式：`/api/v1/{portal}/{domain}`，`{portal}` 取值：`mp | tp | ap | pp | sa`
- 类型定义放在 `src/typings/api.d.ts` 的 `namespace Api` 下

## Store 组织规则

- 每个 store 文件导出一个 `useXxxStore`，使用 Composition API 风格（`defineStore(id, setup)`）
- state 用 `ref`，getter 用 `computed`，action 用 `async function`

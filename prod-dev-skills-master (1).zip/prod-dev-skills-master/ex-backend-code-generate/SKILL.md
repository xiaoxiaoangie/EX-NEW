---
name: ex-backend-code-generate
description: 后端微服务代码生成规范，基于设计文档和接口定义自动生成符合DDD架构的Java代码。此skill会自动触发 ex-backend-project-structure-spec、ex-backend-coding-standards-spec、ex-backend-tech-stack-spec skill。当需要根据设计生成代码时使用。触发场景：用户提到后端代码生成。
---

# 代码生成规范

本 skill 聚焦于代码生成的流程编排和各层生成步骤。

## 生成流程

### 第1步：触发规范 Skill 并确认输入

1. 触发工程结构规范 Skill（`ex-backend-project-structure-spec`）
2. 触发编码规范 Skill（`ex-backend-coding-standards-spec`）
3. 触发技术栈规范 Skill（`ex-backend-tech-stack-spec`）
4. 触发通用术语规范 Skill（`ex-common-terminology-spec`）
5. 确认以下输入：
   - 全量业务设计文档（`docs/designs/full-biz-design.md`）：本服务业务设计的全量文档，理解本服务完整的业务需求和验收标准
   - 需求分析报告（`docs/requirements/{JIRA}-{需求简述}/{JIRA}-reqanalysis-{需求简述}.md`）：本任务的需求分析报告，包含功能需求、非功能需求、接口定义等
   - 全量架构设计文档（`docs/designs/full-architecture-design.md`）：本服务架构设计的全量文档，理解本服务完整的架构设计和实现
   - 全量接口设计文档（`docs/designs/full-api-design.md`）：本服务接口设计的全量文档，理解本服务完整的接口设计和实现
   - 外部集成接口文档：本服务依赖的所有外部集成接口，统一通过防腐层（ACL）隔离
     - 外部系统接口（`docs/external-apis/`）：第三方系统的远程接口，用于生成防腐层实现代码
     - 内部服务Facade契约（`docs/internal-apis/`）：其他微服务的Facade接口，用于生成Feign防腐层实现代码
     - 两者本质都是外部集成，区别仅在于调用方式（远程接口调用 vs Feign调用），代码生成时统一按防腐层模式处理
   - 工程代码（如 bsp-calendar）

### 第2步：按层生成代码（生成代码时要有注释和必要的日志信息，英文）

#### Facade层
1. 生成Feign接口（@FeignClient声明，路径定义）
2. 生成Request/Response DTO（Bean Validation注解）

#### Domain层
1. 生成聚合根（包含基础属性，遵循 `ex-backend-coding-standards-spec` 实体规范）
2. 生成实体和值对象
3. 生成工厂类（静态工厂方法创建领域对象）
4. 生成领域服务接口和实现
5. 生成仓储接口（查询单个返回Optional）
6. 生成防腐层接口（如有）
7. 生成其他

#### App层
1. 生成应用服务接口和实现
2. 编排领域服务调用，处理事务边界
3. 禁止直接调用Repository，禁止业务规则判断

#### Infrastructure层
1. 生成PO对象（对应数据库表结构）
2. 生成MyBatis-Plus Mapper接口（继承BaseMapper）
3. 生成仓储实现（实现Domain层Repository接口，遵循 `ex-backend-coding-standards-spec` 仓储规范）
4. 生成PO转换器（MapStruct）
5. 生成防腐层实现（如有）

#### Web层
1. 生成Controller（实现Facade接口，不声明路径）
2. 生成DTO转换器（MapStruct）
3. 生成启动类（@EnableErrors注解）

#### Common层
1. 生成业务枚举类
2. 生成异常枚举类（使用Error框架，遵循 `ex-backend-coding-standards-spec` 异常处理规范）

#### 数据库脚本
1. 生成Liquibase changelog XML（遵循 `ex-backend-coding-standards-spec` 数据库规范）

### 第3步：生成单元测试

按 `ex-backend-coding-standards-spec` 中的单元测试规范生成：
1. Web层测试（@WebMvcTest + MockMvc）
2. APP层测试（@ExtendWith(MockitoExtension.class)）

### 第4步：更新数据库表结构全景

生成 Liquibase changelog 后，自动更新 `docs/designs/full-database-schema.md`：
1. 读取现有 full-database-schema.md（如存在）
2. 增量更新涉及的表结构
3. 未变更的表保持不变

文档模板见 [database-schema-template.md](references/database-schema-template.md) 。

### 第5步：发送飞书群通知

调度 `ex-common-feishu-notify` 发送飞书群通知，使用**卡片消息**格式，通知内容：

| 字段 | 内容 |
|------|------|
| JIRA单号 | {JIRA} |
| 需求简述 | {需求简述} |
| 执行的Skill | 后端代码生成 |
| 执行时间 | {YYYY-MM-DD HH:mm} |
| 执行人 | {owner} |
| 执行结果 | 成功/失败（附生成文件数） |
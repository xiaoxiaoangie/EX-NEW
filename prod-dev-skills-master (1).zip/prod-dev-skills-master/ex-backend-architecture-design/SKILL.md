---
name: ex-backend-architecture-design
description: 后端微服务架构设计规范，基于需求分析报告进行领域建模、架构决策和设计文档生成。此skill会自动触发 ex-backend-project-structure-spec、ex-backend-coding-standards-spec skill。当需要进行架构设计、编写设计文档时使用。触发场景：用户提到架构设计、服务设计。
---

# 架构设计规范

## 触发规范 Skill

开始架构设计前，必须先触发以下规范 Skill：
1. 触发工程结构规范 Skill（`ex-backend-project-structure-spec`）
2. 触发编码规范 Skill（`ex-backend-coding-standards-spec`）
3. 触发通用术语规范 Skill（`ex-common-terminology-spec`）

## 设计输入

架构设计基于以下输入材料：

1. **本次任务的需求分析报告**（`docs/requirements/{JIRA}-{需求简述}/{JIRA}-reqanalysis-{需求简述}.md`）：核心输入，来自 `ex-backend-requirement-analysis` skill 的输出
   - 新需求场景：包含功能需求清单、业务实体识别、业务规则识别、业务流程
   - 需求变更场景：包含变更内容、变更影响分析、后续阶段执行计划
2. **全量业务设计文档**（`docs/designs/full-biz-design.md`）：本服务业务设计的全量文档，辅助参考完整的功能性需求、非功能性需求、核心业务规则和验收标准
3. **现有架构设计文档**（`docs/designs/full-architecture-design.md`，需求变更场景）：增量更新的基础
4. **外部集成接口文档**：本服务依赖的所有外部集成接口，统一通过防腐层（ACL）隔离
   - 外部系统接口（`docs/external-apis/`）：第三方系统的远程接口，了解接口定义、认证方式、调用约束
   - 内部服务Facade契约（`docs/internal-apis/`）：其他微服务的Facade接口，通过Feign调用
   - 两者本质都是外部集成，区别仅在于调用方式（远程接口调用 vs Feign调用），架构设计时统一按防腐层模式处理

## 设计流程

基于需求分析报告中已识别的业务实体和业务规则，按以下步骤进行架构设计。

### 第1步：领域建模

基于需求分析报告中的"业务实体识别"和"业务规则识别"，进行领域建模：

1. 识别聚合根（Aggregate Root）：核心业务实体，拥有独立生命周期
2. 识别实体（Entity）：有唯一标识，依附于聚合根
3. 识别值对象（Value Object）：无唯一标识，描述属性特征
4. 定义聚合边界：确定哪些对象属于同一聚合
5. 定义领域服务：跨聚合的业务操作
6. 定义仓储接口：每个聚合根对应一个仓储

### 第2步：架构决策

基于领域模型和功能设计，进行以下架构决策：

#### 数据隔离方案
- 确定隔离字段（provider_id、tenant_id等）
- 隔离层次：接口层（HTTP Header）→ 服务层（方法参数）→ 数据层（查询条件）
- 索引设计需将隔离字段作为前缀

#### 缓存策略（按需）
| 场景 | 策略 | 说明 |
|---|---|---|
| 读多写少 | Cache-Aside | 先查缓存，未命中查DB后回填 |
| 写后立即读 | Write-Through | 写DB同时写缓存 |
| 允许延迟 | Write-Behind | 异步批量写DB |

- 缓存Key格式：`{服务名}:{业务key}`
- 写操作时先更新DB再删除缓存
- 设置合理的TTL防止缓存雪崩

#### 消息队列设计（按需）
- Kafka Topic命名：`{服务名}.{聚合}.{动作}`
- 消费者必须实现幂等性，使用唯一业务ID去重
- 失败消息进入死信队列，重试策略：指数退避，最大3次

#### 服务间调用（按需）
- 内部服务：通过Feign声明式接口调用，依赖对方facade Module
- 外部系统：通过防腐层（ACL）隔离，Domain层定义接口，Infrastructure层实现
- 关键调用添加重试和熔断机制

### 第3步：生成设计文档

在 docs/designs/ 目录中输出Markdown格式的设计文档，文件名：`full-architecture-design.md`，文档模板见 [architecture-design-template.md](references/architecture-design-template.md) 。

### 第4步：发送飞书群通知

调度 `ex-common-feishu-notify` 发送飞书群通知，使用**卡片消息**格式，通知内容：

| 字段 | 内容 |
|------|------|
| JIRA单号 | {JIRA} |
| 需求简述 | {需求简述} |
| 执行的Skill | 后端架构设计 |
| 执行时间 | {YYYY-MM-DD HH:mm} |
| 执行人 | {owner} |
| 执行结果 | 成功/失败 |

## 关键原则

### 数据隔离
- EX平台为多租户、多服务商架构
- 租户/服务商之间的数据必须严格隔离
- 所有查询必须带上隔离条件

### 设计约束
- 不设计不必要的功能（如无明确场景的分页查询、删除功能等）
- 每个功能点必须有明确的业务场景支撑
- 架构决策中的缓存、消息队列、服务间调用仅在有明确场景时设计，不过度设计


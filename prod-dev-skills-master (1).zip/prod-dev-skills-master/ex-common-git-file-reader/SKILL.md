---
name: ex-common-git-file-reader
description: 从Git仓库指定目录读取文件内容。支持读取特定分支、特定提交的文件，支持递归读取目录下所有文件。触发场景：用户提到读取Git文件、从Git读取、读取仓库文件、Git文件内容。
---

# 从 Git 读取文件内容

从 Git 仓库的指定目录读取文件内容，支持多种读取模式和过滤条件。

## 前置条件

| 条件 | 说明 |
|------|------|
| Git 环境 | 系统已安装 Git 命令行工具 |
| 仓库访问 | 对目标 Git 仓库有读取权限 |
| 本地仓库 | 如需读取本地仓库，需先 clone 或进入仓库目录 |

## 支持的读取模式

| 模式 | 说明 | 使用场景 |
|------|------|---------|
| 本地仓库 | 读取本地已 clone 的仓库 | 开发环境、CI/CD 环境 |
| 远程仓库 | 通过 HTTPS/SSH 读取远程仓库 | 无需本地 clone 的场景 |
| 特定分支 | 读取指定分支的文件 | 多分支开发场景 |
| 特定提交 | 读取指定 commit 的文件 | 版本追溯、历史对比 |
| 递归读取 | 读取目录下所有文件 | 批量读取场景 |

## 执行流程

### 第1步：确认读取参数

向用户确认以下信息：

1. **仓库地址**（必需）：
   - 本地路径：如 `D:/projects/my-project`
   - 远程地址：如 `https://github.com/user/repo.git` 或 `git@github.com:user/repo.git`

2. **目标路径**（必需）：
   - 文件路径：如 `docs/api/user-api.md`
   - 目录路径：如 `src/components/`

3. **分支/标签**（可选，默认当前分支）：
   - 分支名：如 `develop`、`feature/user-auth`
   - 标签名：如 `v1.0.0`

4. **提交哈希**（可选）：
   - 完整哈希：如 `a1b2c3d4e5f6g7h8i9j0`
   - 短哈希：如 `a1b2c3d`

5. **读取模式**（可选，默认单文件）：
   - 单文件：读取单个文件
   - 递归目录：读取目录下所有文件
   - 过滤模式：按文件扩展名过滤

### 第2步：执行读取操作

#### 模式 A：读取本地仓库

```bash
# 进入仓库目录
cd {local_repo_path}

# 读取当前分支的文件
git show HEAD:{file_path}

# 读取指定分支的文件
git show {branch_name}:{file_path}

# 读取指定提交的文件
git show {commit_hash}:{file_path}

# 递归读取目录下所有文件
git ls-tree -r --name-only HEAD {directory_path}
```

#### 模式 B：读取远程仓库

```bash
# 临时 clone 仓库（浅克隆，只获取最新提交）
git clone --depth 1 --branch {branch_name} {remote_url} temp_repo

# 进入临时目录
cd temp_repo

# 读取文件
cat {file_path}
```

### 第3步：处理文件内容

1. **单文件读取**：
   - 直接返回文件内容
   - 保留原始格式（Markdown、代码等）

2. **目录递归读取**：
   - 列出所有文件路径
   - 按用户选择读取特定文件
   - 或批量读取所有文件内容

3. **文件过滤**：
   - 按扩展名过滤：如只读取 `.md` 文件
   - 按文件名模式过滤：如 `*api*.md`
   - 排除特定文件：如排除 `node_modules/`

### 第4步：返回结果

1. **成功时**：
   - 返回文件内容（文本格式）
   - 提供文件元信息（路径、大小、最后修改时间）
   - 如果是目录，返回文件列表

2. **失败时**：
   - 文件不存在：提示文件路径错误
   - 分支不存在：提示分支名称错误
   - 权限不足：提示检查仓库访问权限
   - 网络错误：提示检查网络连接

## 使用示例

### 示例 1：读取本地仓库单个文件

**用户输入**：
```
读取本地仓库 D:/projects/bsp-calendar 的 docs/api/calendar-api.md 文件
```

**执行步骤**：
1. 确认仓库路径：`D:/projects/bsp-calendar`
2. 确认文件路径：`docs/api/calendar-api.md`
3. 执行命令：`git show HEAD:docs/api/calendar-api.md`
4. 返回文件内容

### 示例 2：读取远程仓库指定分支的文件

**用户输入**：
```
从 https://github.com/ipaylinks/bsp-calendar.git 读取 develop 分支的 README.md
```

**执行步骤**：
1. 确认远程地址：`https://github.com/ipaylinks/bsp-calendar.git`
2. 确认分支：`develop`
3. 确认文件：`README.md`
4. 执行命令：
   ```bash
   git clone --depth 1 --branch develop https://github.com/ipaylinks/bsp-calendar.git temp_repo
   cat temp_repo/README.md
   ```
5. 返回文件内容

### 示例 3：递归读取目录下所有 Markdown 文件

**用户输入**：
```
读取本地仓库 D:/projects/bsp-calendar 的 docs/ 目录下所有 .md 文件
```

**执行步骤**：
1. 确认仓库路径：`D:/projects/bsp-calendar`
2. 确认目录：`docs/`
3. 确认过滤条件：`*.md`
4. 执行命令：
   ```bash
   cd D:/projects/bsp-calendar
   git ls-tree -r --name-only HEAD docs/ | grep '\.md$'
   ```
5. 列出所有 `.md` 文件
6. 按用户选择读取文件内容

### 示例 4：读取特定提交的文件

**用户输入**：
```
读取提交 a1b2c3d 的 src/main/java/CalendarService.java 文件
```

**执行步骤**：
1. 确认提交哈希：`a1b2c3d`
2. 确认文件路径：`src/main/java/CalendarService.java`
3. 执行命令：`git show a1b2c3d:src/main/java/CalendarService.java`
4. 返回文件内容

## 错误处理

| 错误场景 | 处理方式 |
|----------|---------|
| 仓库不存在 | 提示用户确认仓库地址是否正确 |
| 文件不存在 | 提示用户确认文件路径，列出目录下可用文件 |
| 分支不存在 | 提示用户确认分支名称，列出可用分支 |
| 提交不存在 | 提示用户确认提交哈希是否正确 |
| 权限不足 | 提示用户检查 Git 凭据或 SSH 密钥配置 |
| 网络超时 | 重试 1 次，仍失败则报告错误 |
| 文件过大 | 提示文件大小，询问是否继续读取或分块读取 |

## 注意事项

1. **大文件处理**：
   - 文件超过 1MB 时提示用户确认
   - 提供分块读取选项

2. **二进制文件**：
   - 检测文件类型，提示无法读取二进制文件
   - 仅支持文本文件读取

3. **编码问题**：
   - 默认使用 UTF-8 编码
   - 遇到编码错误时尝试其他编码（GBK、ISO-8859-1）

4. **临时文件管理**：
   - 读取远程仓库时创建的临时目录保留在本地，便于后续操作
   - 临时目录位置：`./temp_repo`
   - 用户可根据需要手动清理临时目录

5. **安全性**：
   - 不执行任何 Git 命令的修改操作
   - 只读取文件内容，不修改仓库状态
   - 敏感信息（如密码、密钥）需用户确认后才显示

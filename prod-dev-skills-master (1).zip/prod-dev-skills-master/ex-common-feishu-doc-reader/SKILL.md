---
name: ex-common-feishu-doc-reader
description: 读取飞书链接文档内容。默认通过飞书开放平台 blocks API 重建可读文本；若文档中存在飞书 Mermaid 文本绘图块，则还原为 Markdown 的 ```mermaid code block。触发场景：用户提到读取飞书文档、获取飞书链接内容、飞书文档导入、从飞书读取。
---

# 读取飞书文档

通过飞书开放平台 API 读取文档内容，并尽可能还原为结构化文本。

对于普通文本，输出接近 Markdown 的可读内容。

对于 Mermaid，必须特别处理：

- 若文档中存在飞书 Mermaid 文本绘图块（`block_type = 40`，特定 `component_type_id`），需要把它还原为：

````markdown
```mermaid
...
```
````

不要只调用 `raw_content` 就结束。`raw_content` 会丢失 Mermaid 图、块类型和结构信息。

## 前置条件

| 条件 | 说明 |
|------|------|
| 飞书应用凭证 | 需要 `FEISHU_APP_ID` 和 `FEISHU_APP_SECRET` |
| API 权限 | 至少需要 `docx:document:readonly` |
| 文档授权 | 目标文档需授权给该应用 |

## 支持的链接格式

| 链接格式 | 文档类型 | token 位置 |
|----------|---------|-----------|
| `https://{domain}.feishu.cn/docx/{token}` | 新版文档（docx） | URL 路径最后一段 |
| `https://{domain}.feishu.cn/wiki/{token}` | 知识库文档（wiki） | URL 路径最后一段 |
| `https://{domain}.feishu.cn/doc/{token}` | 旧版文档（doc） | URL 路径最后一段 |
| `https://{domain}.feishu.cn/sheets/{token}` | 电子表格（sheet） | URL 路径最后一段 |

## Mermaid 识别原则

### 必须识别的 Mermaid 类型

飞书 Mermaid 文本绘图块特征：

- `block_type = 40`
- `add_ons.component_type_id = "blk_631fefbbae02400430b8f9f4"`
- `add_ons.record` 是一个 JSON 字符串
- 其中 `record.data` 为 Mermaid 源码

读取到这类块时，必须输出为 Markdown 的 Mermaid 代码块，而不是：

- `[Mermaid 图]`
- 普通段落
- 原样 JSON

### 需要注意的历史兼容

如果文档里是旧方案生成的 whiteboard（`block_type = 43`）：

- 可以通过 `board/v1/whiteboards/{whiteboard_id}/nodes` 读取节点
- 但公开 API 通常拿不到原始 Mermaid 源码
- 这类内容不能可靠还原为原始 ```` ```mermaid ```` 代码块

因此：

1. `block_type = 40` Mermaid add-on：还原为 Mermaid code block
2. `block_type = 43` whiteboard：只输出说明性占位文本，除非调用方明确接受“节点结构转述”

## 执行流程

### 第1步：解析飞书链接

1. 提取飞书文档 URL
2. 识别文档类型：`docx`、`wiki`、`doc`、`sheets`
3. 提取 token
4. 若格式不匹配，直接报错，不要猜

### 第2步：获取访问凭证

调用：

```http
POST https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal
Content-Type: application/json; charset=utf-8

{
  "app_id": "{APP_ID}",
  "app_secret": "{APP_SECRET}"
}
```

凭证来源优先级：

1. 环境变量 `FEISHU_APP_ID` / `FEISHU_APP_SECRET`
2. 项目 `.env`
3. 向用户询问

### 第3步：解析 wiki 到实际文档（如需要）

若是 wiki 链接，先调用：

```http
GET https://open.feishu.cn/open-apis/wiki/v2/spaces/get_node?token={node_token}
Authorization: Bearer {tenant_access_token}
```

从返回值中获取：

- `obj_token`
- `obj_type`

然后按实际对象类型继续读取。

### 第4步：优先使用 blocks API 读取 docx 内容

对于 `docx`，默认不要直接用 `raw_content`。

优先调用：

```http
GET https://open.feishu.cn/open-apis/docx/v1/documents/{document_id}/blocks?document_revision_id=-1&page_size=500
Authorization: Bearer {tenant_access_token}
```

必要时翻页读取全部块。

目标是拿到：

- 根页面块及其 children 顺序
- 各 block 的类型与内容
- Mermaid add-on 块
- 表格、列表、代码块等结构

### 第5步：将 blocks 重建为文本

按根页面 children 顺序输出内容。

建议映射：

| 飞书块 | 输出格式 |
|--------|---------|
| `block_type=2` 文本 | 普通段落 |
| `3-8` 标题 | `#` 到 `######` |
| `12` 无序列表 | `- item` |
| `13` 有序列表 | `1. item` |
| `14` 代码块 | 普通 fenced code block |
| `15` 引用 | `> quote` |
| `22` 分割线 | `---` |
| `31/32` 表格 | 尽可能重建 Markdown 表格，否则退化为结构化文本 |
| `40` Mermaid add-on | 还原为 ```mermaid |
| `43` whiteboard | 输出说明文本，标记无法无损还原源码 |

### 第6步：还原 Mermaid add-on

当块满足：

- `block_type = 40`
- `add_ons.component_type_id = "blk_631fefbbae02400430b8f9f4"`

处理方式：

1. 解析 `add_ons.record` 这个 JSON 字符串
2. 提取：
   - `data`
   - 可选的 `theme`
   - 可选的 `view`
3. 输出为：

````markdown
```mermaid
{data}
```
````

如果 `record` 解析失败：

- 不要静默忽略
- 输出说明：该块是 Mermaid，但 `record` 解析失败

### 第7步：仅在必要时补充 raw_content

`raw_content` 可作为兜底或校验，不作为主读取方式：

```http
GET https://open.feishu.cn/open-apis/docx/v1/documents/{document_id}/raw_content?lang=0
Authorization: Bearer {tenant_access_token}
```

适用场景：

- blocks API 返回异常
- 只需要纯文本快速预览
- 与重建内容做简单校验

但只要用户关心 Mermaid、代码块、结构化内容，就必须优先使用 blocks API。

### 第8步：返回结果

1. 返回重建后的文本内容
2. 若文档很长，可截断，但要说明截断
3. 若存在 Mermaid，还原为 ```mermaid 代码块
4. 若存在 whiteboard 且无法还原源码，明确提示是历史 whiteboard 图

## 推荐实现

若当前 skill 目录下存在可复用脚本，优先使用：

- `scripts/feishu_read_document.py`

## 文档类型处理建议

| 类型 | 建议 |
|------|------|
| `docx` | 走 blocks API，必要时辅以 raw_content |
| `wiki` | 先转实际对象，再按对象类型处理 |
| `doc` | 若无法获取结构化块，可退化为纯文本 |
| `sheets` | 读表结构，不要求 Mermaid 处理 |

## 错误处理

| 错误场景 | 处理方式 |
|----------|---------|
| 链接格式无法识别 | 提示用户确认链接格式 |
| 应用凭证未配置 | 提示配置 `FEISHU_APP_ID`、`FEISHU_APP_SECRET` |
| 文档无权限（403） | 提示将应用加入文档协作者 |
| 文档不存在（404） | 提示确认链接是否正确或文档是否已删除 |
| API 限流 | 等待 1 秒后重试，最多 3 次 |
| Mermaid `record` 解析失败 | 保留说明文本并报告失败 |

## 已知限制

| 限制 | 说明 |
|------|------|
| `raw_content` 不保留 Mermaid 结构 | 不能作为 Mermaid 读取主方案 |
| whiteboard 无法稳定反推原 Mermaid | 只能读取节点，不能无损回原始源码 |
| 表格与复杂嵌套块可能无法完全还原 | 可接受有限降级，但要保持 Mermaid 不丢失 |

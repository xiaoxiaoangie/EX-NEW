#!/usr/bin/env python3
import argparse
import json
import os
import re
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional, Tuple


BASE_URL = "https://open.feishu.cn/open-apis"
MERMAID_COMPONENT_TYPE_ID = "blk_631fefbbae02400430b8f9f4"

# Create SSL context that skips verification for self-signed certificates
_ssl_context = ssl.create_default_context()
_ssl_context.check_hostname = False
_ssl_context.verify_mode = ssl.CERT_NONE


def normalize_whitespace(text: str) -> str:
    return re.sub(r"\n{3,}", "\n\n", text.strip())


class FeishuClient:
    def __init__(self, app_id: str, app_secret: str):
        self.app_id = app_id
        self.app_secret = app_secret
        self.token: Optional[str] = None

    def request(self, method: str, path: str, payload: Optional[dict] = None) -> dict:
        headers = {"Content-Type": "application/json; charset=utf-8"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload is not None else None
        req = urllib.request.Request(f"{BASE_URL}{path}", data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=120, context=_ssl_context) as resp:
                body = resp.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"{method} {path} failed: HTTP {exc.code}: {detail}") from exc
        parsed = json.loads(body)
        if parsed.get("code") != 0:
            raise RuntimeError(f"{method} {path} failed: {body}")
        return parsed

    def authenticate(self) -> None:
        resp = self.request(
            "POST",
            "/auth/v3/tenant_access_token/internal",
            {"app_id": self.app_id, "app_secret": self.app_secret},
        )
        self.token = resp["tenant_access_token"]

    def resolve_wiki(self, token: str) -> Tuple[str, str]:
        resp = self.request("GET", f"/wiki/v2/spaces/get_node?token={urllib.parse.quote(token)}")
        node = resp["data"]["node"]
        return node["obj_type"], node["obj_token"]

    def list_blocks(self, document_id: str) -> List[dict]:
        items: List[dict] = []
        page_token = ""
        while True:
            query = urllib.parse.urlencode(
                {
                    "document_revision_id": -1,
                    "page_size": 500,
                    **({"page_token": page_token} if page_token else {}),
                }
            )
            resp = self.request("GET", f"/docx/v1/documents/{document_id}/blocks?{query}")
            data = resp["data"]
            items.extend(data.get("items", []))
            if not data.get("has_more"):
                return items
            page_token = data["page_token"]

    def raw_content(self, document_id: str) -> str:
        resp = self.request("GET", f"/docx/v1/documents/{document_id}/raw_content?lang=0")
        return resp["data"]["content"]


def parse_link(url: str) -> Tuple[str, str]:
    match = re.search(r"/(docx|wiki|doc|sheets)/([^/?#]+)", url)
    if not match:
        raise RuntimeError(f"Unsupported Feishu URL: {url}")
    return match.group(1), match.group(2)


def text_from_elements(elements: List[dict]) -> str:
    chunks: List[str] = []
    for element in elements:
        if "text_run" in element:
            chunks.append(element["text_run"].get("content", ""))
        elif "equation" in element:
            chunks.append(element["equation"].get("content", ""))
    return "".join(chunks)


def block_to_markdown(block: dict) -> str:
    block_type = block.get("block_type")
    if block_type == 2:
        return text_from_elements(block.get("text", {}).get("elements", []))
    if block_type in (3, 4, 5, 6, 7, 8):
        level = block_type - 2
        key = f"heading{level}"
        return f"{'#' * level} {text_from_elements(block.get(key, {}).get('elements', []))}"
    if block_type == 12:
        return f"- {text_from_elements(block.get('bullet', {}).get('elements', []))}"
    if block_type == 13:
        return f"1. {text_from_elements(block.get('ordered', {}).get('elements', []))}"
    if block_type == 14:
        code = text_from_elements(block.get("code", {}).get("elements", []))
        return f"```\n{code}\n```"
    if block_type == 15:
        return f"> {text_from_elements(block.get('quote', {}).get('elements', []))}"
    if block_type == 22:
        return "---"
    if block_type == 40:
        add_ons = block.get("add_ons", {})
        if add_ons.get("component_type_id") == MERMAID_COMPONENT_TYPE_ID:
            try:
                record = json.loads(add_ons.get("record", "{}"))
                return f"```mermaid\n{record.get('data', '')}\n```"
            except json.JSONDecodeError:
                return "[Mermaid block: record parse failed]"
        return "[Unsupported add-on block]"
    if block_type == 43:
        return "[Whiteboard block: source Mermaid code not recoverable via public API]"
    if block_type == 31:
        return "[Table block]"
    if block_type == 27:
        return "[Image block]"
    return ""


def render_docx(blocks: List[dict], document_id: str) -> str:
    page = next((item for item in blocks if item.get("block_type") == 1 and item.get("block_id") == document_id), None)
    if not page:
        raise RuntimeError("Root page block not found")
    blocks_by_id: Dict[str, dict] = {block["block_id"]: block for block in blocks}
    parts: List[str] = []
    for child_id in page.get("children", []):
        block = blocks_by_id.get(child_id)
        if not block:
            continue
        text = block_to_markdown(block)
        if text:
            parts.append(text)
    return normalize_whitespace("\n\n".join(parts)) + "\n"


def read_document(url: str) -> dict:
    app_id = os.getenv("FEISHU_APP_ID")
    app_secret = os.getenv("FEISHU_APP_SECRET")
    if not app_id or not app_secret:
        raise RuntimeError("FEISHU_APP_ID and FEISHU_APP_SECRET are required")

    client = FeishuClient(app_id, app_secret)
    client.authenticate()

    doc_type, token = parse_link(url)
    if doc_type == "wiki":
        obj_type, obj_token = client.resolve_wiki(token)
        doc_type, token = obj_type, obj_token

    if doc_type != "docx":
        content = client.raw_content(token)
        return {"document_id": token, "doc_type": doc_type, "content": content}

    blocks = client.list_blocks(token)
    content = render_docx(blocks, token)
    return {"document_id": token, "doc_type": doc_type, "content": content}


def main() -> int:
    parser = argparse.ArgumentParser(description="Read a Feishu document and reconstruct Markdown-ish text with Mermaid blocks.")
    parser.add_argument("url", help="Feishu docx/wiki URL")
    parser.add_argument("--output", help="Optional output file path")
    args = parser.parse_args()

    result = read_document(args.url)
    content = result["content"]
    if args.output:
        Path(args.output).write_text(content, encoding="utf-8")
    else:
        sys.stdout.write(content)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

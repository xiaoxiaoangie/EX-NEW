---
name: ex-qa-full-regression
description: 全量回归测试，每日定时执行全量已有的 E2E 测试脚本，验证系统整体功能是否正常。不生成新脚本，只执行和报告。触发场景：用户提到全量回归。
---

# 全量回归测试

每日定时执行所有已有的 E2E 测试脚本，验证系统整体功能是否正常。不生成新脚本，只执行和报告。

触发以下基础规范（自动引用，无需单独调度）：

- `ex-frontend-tech-stack-spec`：前端技术栈规范（Playwright 版本等）
- `ex-common-terminology-spec`：通用术语规范
- `ex-common-biz-arch-spec`：业务架构规范（角色、数据隔离规则）

## QA 工程目录结构

QA 作为独立环节，拥有独立的工程目录，与前端工程和后端工程平级：

```
{qa-project}/                                    # QA 验收工程（独立 Git 仓库或独立目录）
├── README.md                                    # QA 工程说明、环境配置、运行方式
├── projects.json                                # 项目注册表（业务域与前后端工程的映射关系）
├── package.json                                 # Playwright + TypeScript 依赖
├── playwright.config.ts                         # Playwright 配置（baseURL、超时、报告等）
├── tsconfig.json
│
├── fixtures/                                    # 测试固件
│   ├── auth.ts                                  # 登录认证（各角色 token 获取与切换，供所有测试用例作为前置条件使用）
│   ├── test-data.ts                             # 测试数据工厂
│   └── api-client.ts                            # 后端 API 客户端封装
│
├── e2e/                                         # E2E 测试脚本
│   ├── common/                                  # 公共域（登录、权限、导航等跨业务域场景）
│   │   ├── login.spec.ts                        # 登录场景（登录失败、密码重置、MFA、会话超时等）
│   │   ├── navigation.spec.ts                   # 导航场景（菜单、路由、面包屑等）
│   │   └── permission.spec.ts                   # 权限场景（角色权限、菜单可见性等）
│   └── {domain}/                                # 按业务域组织（不是按 portal）
│       ├── {scenario-name}.spec.ts              # 前端 E2E 测试（可跨多个 portal）
│       └── {scenario-name}.api.spec.ts          # 后端 API 验证（HTTP 接口测试）
│
├── docs/                                        # QA 文档
│   ├── full-qa-testcases/                       # 按业务域拆分全量 E2E 测试用例
│   │   ├── common.md                            # 公共域全量 E2E 用例
│   │   └── {domain}.md                          # 各业务域全量 E2E 用例，增量累积
│   └── {domain}/                                # 按业务域组织增量用例和验收报告
│       └── {jira}-{summary}/
│           ├── {jira}-qa-testcases-{summary}.md # 本次增量 E2E 测试用例
│           └── {jira}-qa-report-{summary}.md    # 验收报告
│
└── test-results/                                # 测试执行结果（gitignore）
    ├── html/                                    # HTML 报告
    └── json/                                    # JSON 报告
```

### 项目注册表（projects.json）

全量回归通过 `projects.json` 中的 `domains` 配置了解业务域划分，用于按域统计测试结果。

**格式**：

```json
{
  "repos": {
    "ex-mp": {
      "url": "https://gitlab.internal/ex/frontend-mp.git",
      "branch": "develop",
      "docsPath": "docs"
    }
  },
  "domains": {
    "user": {
      "frontend": ["ex-mp", "ex-tp"],
      "backend": ["ex-user-service", "ex-auth-service"]
    },
    "payment": {
      "frontend": ["ex-mp"],
      "backend": ["ex-payment-service", "ex-transaction-service"]
    }
  },
  "common": {
    "frontend": ["ex-sa"],
    "backend": ["ex-auth-service", "ex-system-service"]
  }
}
```

> **说明**：全量回归只使用 `domains` 和 `common` 字段来识别业务域划分，不使用 `repos` 读取文档。

### 公共域与业务域的区分

| 场景 | 归属 | 说明 |
|------|------|------|
| 各角色登录成功 | `fixtures/auth.ts` | 作为其他测试的前置条件，不是测试目标 |
| 登录失败（密码错误、账号锁定） | `e2e/common/login.spec.ts` | 登录域自身的业务场景 |
| 密码重置、MFA 验证 | `e2e/common/login.spec.ts` | 登录域自身的业务场景 |
| 会话超时、Token 刷新 | `e2e/common/login.spec.ts` | 登录域自身的业务场景 |
| 角色权限控制 | `e2e/common/permission.spec.ts` | 公共域场景 |
| 付款流程中切换角色 | `e2e/payment/payment-flow.spec.ts` | 业务域内使用 fixture |

### E2E 用例编号规范

- 格式：`TC-E{场景序号}{用例序号}`
- 示例：TC-E0101（第1个场景的第1个 E2E 用例）
- 全量文档和增量文档使用相同的编号体系，确保一致性

## 输入

| 来源 | 是否必须 | 说明 |
|------|---------|------|
| 已部署的测试环境 | 必须 | 前端服务 URL + 后端服务 URL |
| 已有的 E2E 测试脚本 | 必须 | `e2e/` 目录下已生成的 Playwright 脚本 |

> **说明**：全量回归不读取任何文档，不生成新脚本，只执行已有脚本并报告结果。

## 回归流程

### 第1步：获取基本信息

1. 记录回归开始时间 `{startTime}`（格式：YYYY-MM-DD HH:mm）
2. 确认 QA 工程路径 `{qa-project}`：
   - 如用户当前工作目录即为 QA 工程，自动识别
   - 否则询问用户提供 QA 工程根目录
3. 确认测试环境：
   - 各 Portal 前端服务地址（如 `https://test-mp.ex.com`、`https://test-tp.ex.com`、`https://test-ap.ex.com`、`https://test-pp.ex.com`、`https://test-sa.ex.com`）
   - 后端服务地址（如 `https://test-api.ex.com`）
   - 登录凭证（各角色测试账号：商户、租户管理员、代理商、服务商、运营管理员）
4. 扫描测试范围：
   - 扫描 `e2e/` 目录下所有 `.spec.ts` 文件
   - 列出本次将执行的业务域和用例数
   - 如需指定特定业务域，询问用户确认

### 第2步：执行全量回归测试

1. 执行全部 E2E 测试：
   ```bash
   npx playwright test --reporter=html,json
   ```

2. 如需按业务域执行：
   ```bash
   npx playwright test e2e/{domain}/ --reporter=html,json
   ```

3. 收集测试结果：
   - 通过/失败/阻塞的用例数
   - 失败用例的截图和错误信息
   - 每个用例的执行时间
   - 按业务域统计通过率

4. 对失败用例进行分析分类：
   - **脚本问题**：选择器失效、时序问题、数据问题
   - **环境问题**：服务不可用、配置错误、数据未初始化
   - **真实 Bug**：系统功能确实存在缺陷

**⚠️ 必须停下等待用户审阅测试结果，不允许跳过**

### 第3步：修复与回归

根据用户反馈和测试结果：

1. **脚本问题**：修复测试脚本，重新执行
2. **环境问题**：修复环境配置，重新执行
3. **真实 Bug**：记录到回归报告的缺陷清单中，由开发团队修复
4. 修复后重新执行失败的用例：
   ```bash
   npx playwright test --last-failed
   ```
5. 循环修复直到所有非 Bug 类失败用例通过

**⚠️ 必须停下等待用户确认测试结果，不允许跳过**

### 第4步：生成回归报告

生成回归报告，文件路径：`docs/full-qa-testcases/full-regression-report-{date}.md`

**报告内容**：

| 章节 | 说明 |
|------|------|
| 回归概要 | 执行日期、测试环境、执行人 |
| 测试范围 | 本次执行覆盖的业务域和用例数 |
| 测试结果汇总 | 总用例数、通过数、失败数、阻塞数、通过率 |
| 按业务域统计 | 每个业务域的通过率、失败用例数 |
| 失败用例详情 | 每个失败用例的分类（脚本/环境/Bug）、截图、错误信息 |
| 缺陷清单 | 真实 Bug 列表（编号、场景、严重程度、描述、状态） |
| 回归结论 | 通过（系统正常）/ 有条件通过（附遗留问题）/ 不通过（阻塞发布） |

**回归结论规则**：
- **通过**：所有用例通过，无 P0/P1 缺陷
- **有条件通过**：存在 P2 缺陷但不影响核心业务流程，需记录遗留问题并约定修复时间
- **不通过**：存在 P0/P1 缺陷或核心业务流程失败，阻塞发布

### 第5步：发送飞书群通知

调度 `ex-common-feishu-notify` 发送飞书群通知，使用**卡片消息**格式，通知内容：

| 字段 | 内容 |
|------|------|
| 执行类型 | 全量回归测试 |
| 执行日期 | {date} |
| 开始时间 | {startTime} |
| 完成时间 | {endTime} |
| 执行人 | {owner} |
| 执行结果 | 通过/有条件通过/不通过（附通过率、P0/P1缺陷数） |
| 业务域通过率 | 各业务域通过率概览 |

## 产出物

| 产出物 | 路径 | 说明 |
|--------|------|------|
| 回归报告 | `docs/full-qa-testcases/full-regression-report-{date}.md` | 全量回归报告 |

## 注意事项

- 全量回归不生成新脚本，如需新增或修改脚本，使用 `ex-qa-incremental`
- 每个测试用例必须独立，不依赖其他用例的执行顺序或副作用
- 跨 Portal 角色切换时，必须清除前一个角色的登录态（Cookie、localStorage），避免角色串扰
- 网络请求使用 `page.waitForResponse()` 等待，避免硬编码 `page.waitForTimeout()`
- 金额相关断言必须验证精度，避免浮点数比较问题
- 测试报告中的失败用例必须区分"脚本问题"、"环境问题"和"真实 Bug"
- 回归报告的结论直接影响发布决策，必须客观准确
- 全量回归由 CI/CD 定时调度执行，如发现真实 Bug，通知开发团队修复后由 `ex-qa-incremental` 重新验收

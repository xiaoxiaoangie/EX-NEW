---
name: ex-qa-incremental
description: 增量质量验收，单个 JIRA 需求开发完成后，从 Git 仓库读取文档，按业务场景组织测试，生成 E2E 测试脚本并执行，验证系统是否满足业务验收标准。触发场景：用户提到用户验收、用户测试、E2E测试。
---

# 增量质量验收

单个 JIRA 需求开发完成后，从 Git 仓库按需读取文档，按业务场景组织测试，生成 E2E 测试脚本并执行，验证系统是否满足业务验收标准。

与开发流程中的测试定位不同：

| 维度 | 开发流程中的测试 | 增量质量验收（本 Skill） |
|------|---------------|----------------------|
| 回答的问题 | "我写的代码对不对？" | "系统整体满不满足业务验收标准？" |
| 测试视角 | 技术视角（代码正确性） | 用户/业务视角（业务正确性） |
| 测试范围 | 单个服务或单个页面 | 跨前后端的完整业务场景 |
| 执行者 | AI + 开发者 | 质量团队 |
| 失败含义 | 代码有 bug，开发者必须立即修 | 系统不符合预期，可能阻塞发布 |
| 时机 | 开发过程中即时执行 | 开发完成后集中执行 |

触发以下基础规范（自动引用，无需单独调度）：

- `ex-frontend-tech-stack-spec`：前端技术栈规范（Playwright 版本等）
- `ex-frontend-project-structure-spec`：前端工程结构规范
- `ex-common-terminology-spec`：通用术语规范
- `ex-common-biz-arch-spec`：业务架构规范（角色、数据隔离规则）

## QA 工程目录结构

QA 作为独立环节，拥有独立的工程目录，与前端工程和后端工程平级：

```
{qa-project}/                                    # QA 验收工程（独立 Git 仓库或独立目录）
├── README.md                                    # QA 工程说明、环境配置、运行方式
├── projects.json                                # 项目注册表（业务域与前后端工程的映射关系）
├── package.json                                 # Playwright + TypeScript 依赖
├── playwright.config.ts                         # Playwright 配置（baseURL、超时、报告等）
├── tsconfig.json
│
├── fixtures/                                    # 测试固件
│   ├── auth.ts                                  # 登录认证（各角色 token 获取与切换，供所有测试用例作为前置条件使用）
│   ├── test-data.ts                             # 测试数据工厂
│   └── api-client.ts                            # 后端 API 客户端封装
│
├── e2e/                                         # E2E 测试脚本
│   ├── common/                                  # 公共域（登录、权限、导航等跨业务域场景）
│   │   ├── login.spec.ts                        # 登录场景（登录失败、密码重置、MFA、会话超时等）
│   │   ├── navigation.spec.ts                   # 导航场景（菜单、路由、面包屑等）
│   │   └── permission.spec.ts                   # 权限场景（角色权限、菜单可见性等）
│   └── {domain}/                                # 按业务域组织（不是按 portal）
│       ├── {scenario-name}.spec.ts              # 前端 E2E 测试（可跨多个 portal）
│       └── {scenario-name}.api.spec.ts          # 后端 API 验证（HTTP 接口测试）
│
├── docs/                                        # QA 文档
│   ├── full-qa-testcases/                       # 按业务域拆分全量 E2E 测试用例
│   │   ├── common.md                            # 公共域全量 E2E 用例
│   │   └── {domain}.md                          # 各业务域全量 E2E 用例，增量累积
│   └── {domain}/                                # 按业务域组织增量用例和验收报告
│       └── {jira}-{summary}/
│           ├── {jira}-qa-testcases-{summary}.md #【AI生成】本次增量 E2E 测试用例
│           └── {jira}-qa-report-{summary}.md    #【AI生成】验收报告
│
└── test-results/                                # 测试执行结果（gitignore）
    ├── html/                                    # HTML 报告
    └── json/                                    # JSON 报告
```

### 项目注册表（projects.json）

QA 工程根目录下的 `projects.json` 维护业务域与前后端 Git 仓库的映射关系，一次配置反复使用。

**设计原则**：QA 不需要拉取前后端源码，只需读取各工程的文档（docs 目录）。通过 `ex-common-git-file-reader` 按需浅克隆 docs 目录，用完即删。

**格式**：

```json
{
  "repos": {
    "ex-mp": {
      "url": "https://gitlab.internal/ex/frontend-mp.git",
      "branch": "develop",
      "docsPath": "docs"
    },
    "ex-tp": {
      "url": "https://gitlab.internal/ex/frontend-tp.git",
      "branch": "develop",
      "docsPath": "docs"
    },
    "ex-user-service": {
      "url": "https://gitlab.internal/ex/user-service.git",
      "branch": "develop",
      "docsPath": "docs"
    },
    "ex-payment-service": {
      "url": "https://gitlab.internal/ex/payment-service.git",
      "branch": "develop",
      "docsPath": "docs"
    }
  },
  "domains": {
    "user": {
      "frontend": ["ex-mp", "ex-tp"],
      "backend": ["ex-user-service", "ex-auth-service"]
    },
    "payment": {
      "frontend": ["ex-mp"],
      "backend": ["ex-payment-service", "ex-transaction-service"]
    },
    "merchant": {
      "frontend": ["ex-mp", "ex-tp", "ex-ap"],
      "backend": ["ex-merchant-service"]
    }
  },
  "common": {
    "frontend": ["ex-sa"],
    "backend": ["ex-auth-service", "ex-system-service"]
  }
}
```

**字段说明**：

| 字段 | 说明 |
|------|------|
| `repos` | 所有关联的 Git 仓库注册信息，key 为仓库简称 |
| `repos.{name}.url` | Git 仓库地址（HTTPS 或 SSH） |
| `repos.{name}.branch` | 默认读取分支（多分支并行时，验收时确认具体分支） |
| `repos.{name}.docsPath` | 文档目录的相对路径（默认 `docs`） |
| `domains.{domain}` | 业务域名称，与 `e2e/{domain}/` 目录名一致 |
| `domains.{domain}.frontend` | 该业务域涉及的前端仓库简称列表 |
| `domains.{domain}.backend` | 该业务域涉及的后端仓库简称列表 |
| `common` | 公共域，对应 `e2e/common/` 的测试场景 |

**文档读取规则**：
1. 通过 `ex-common-git-file-reader` 按需浅克隆（`--depth 1`），只读取 `{docsPath}` 目录下的文档
2. 读取完成后删除临时克隆目录（`./temp_repo`），不保留源码
3. 验收时如需切换分支，覆盖 `repos.{name}.branch` 的默认值

**注册表维护规则**：
1. 首次执行 QA 验收时，如 `projects.json` 不存在，引导用户创建
2. 每次验收时，根据 `{domain}` 从注册表中查找关联仓库
3. 如业务域未注册，询问用户提供仓库信息并自动追加到注册表
4. 如仓库地址或分支已变更，更新注册表

### 公共域与业务域的区分

| 场景 | 归属 | 说明 |
|------|------|------|
| 各角色登录成功 | `fixtures/auth.ts` | 作为其他测试的前置条件，不是测试目标 |
| 登录失败（密码错误、账号锁定） | `e2e/common/login.spec.ts` | 登录域自身的业务场景 |
| 密码重置、MFA 验证 | `e2e/common/login.spec.ts` | 登录域自身的业务场景 |
| 会话超时、Token 刷新 | `e2e/common/login.spec.ts` | 登录域自身的业务场景 |
| 角色权限控制 | `e2e/common/permission.spec.ts` | 公共域场景 |
| 付款流程中切换角色 | `e2e/payment/payment-flow.spec.ts` | 业务域内使用 fixture |

### E2E 用例编号规范

- 格式：`TC-E{场景序号}{用例序号}`
- 示例：TC-E0101（第1个场景的第1个 E2E 用例）
- 全量文档和增量文档使用相同的编号体系，确保一致性

## 输入

| 来源 | 是否必须 | 说明 |
|------|---------|------|
| JIRA 单号 | 必须 | 任务唯一标识 |
| 前端测试用例文档 | 必须 | 前端仓库 `docs/{domain}/designs/full-testcases.md` 中的 E2E 测试用例 |
| 后端测试用例文档 | 必须 | 后端仓库 `docs/designs/full-testcases.md` 中的集成测试用例 |
| PRD | 必须 | 全量 PRD 或增量 PRD，作为业务验收标准来源 |
| 页面原型 | 必须 | 前端仓库 `docs/{domain}/prototypes/*.html`，了解页面交互预期 |
| 后端接口文档 | 必须 | 后端仓库 `docs/designs/full-api-design.md`，了解接口定义 |
| 已部署的测试环境 | 必须 | 前端服务 URL + 后端服务 URL |

> **说明**：QA 不读取前后端源码，所有文档输入均来自各工程 docs 目录，通过 `ex-common-git-file-reader` 从 Git 仓库按需浅克隆读取，用完即删。

## 验收流程

### 第1步：获取基本信息

1. 获取 JIRA 单号（强制第一步）
2. 获取负责人（执行 `git config user.email` 或手动输入）
3. 记录验收开始时间 `{startTime}`（格式：YYYY-MM-DD HH:mm）
4. 确认 QA 工程路径 `{qa-project}`：
   - 如用户当前工作目录即为 QA 工程，自动识别
   - 否则询问用户提供 QA 工程根目录
5. 确认业务域（强制，记录为 `{domain}`）
   - 询问用户当前验收任务属于哪个业务域（如：user、order、payment 等）
6. 从项目注册表获取关联仓库：
   - 读取 `{qa-project}/projects.json`
   - 如注册表不存在，引导用户创建（按 `projects.json` 格式说明）
   - 根据 `{domain}` 查找关联的前端仓库列表和后端仓库列表
   - 如业务域未注册，询问用户提供仓库信息并自动追加到注册表
   - 确认各仓库的验收分支（默认使用注册表中的 `branch`，多分支并行时由用户指定）
7. 确认测试环境：
   - 各 Portal 前端服务地址（如 `https://test-mp.ex.com`、`https://test-tp.ex.com`、`https://test-ap.ex.com`、`https://test-pp.ex.com`、`https://test-sa.ex.com`）
   - 后端服务地址（如 `https://test-api.ex.com`）
   - 登录凭证（各角色测试账号：商户、租户管理员、代理商、服务商、运营管理员）

### 第2步：按业务场景组织测试

从 Git 仓库按需读取文档，将前后端测试用例按业务场景合并：

1. 调度 `ex-common-git-file-reader`，对每个关联仓库浅克隆（`--depth 1`），只读取 `{docsPath}` 目录
2. 读取完成后删除临时克隆目录（`./temp_repo`），不保留源码
3. 提取的文档：前端测试用例、后端测试用例、PRD、页面原型、后端接口文档
4. 将前后端测试用例按业务场景合并，每个场景覆盖完整的前后端链路

**场景组织原则**：
- 以 PRD 中的业务流程为主线，每个业务流程对应一个测试场景
- 每个场景包含：前端用户操作（Playwright）+ 后端接口验证（HTTP 请求）
- 场景之间可复用登录态，但每个场景必须独立可执行

**跨 Portal 角色切换**：
- E2E 测试按业务域组织，不按 portal 组织。一个完整业务流程可能跨多个 portal，通过角色切换实现
- 角色与 portal 对应关系：商户(mp)、租户(tp)、代理商(ap)、服务商(pp)、运营(sa)
- 在测试脚本中通过 `loginAs(role, user)` 切换角色，每个角色对应不同的 portal 和权限
- 示例：商户入网全流程 = 租户(tp)配置产品 → 代理商(ap)推荐商户 → 商户(mp)提交入网 → 租户(tp)审核通过

**场景分类**：

| 场景类型 | 前端验证 | 后端验证 | 断言重点 |
|---------|---------|---------|---------|
| 完整业务流程 | 用户操作路径、页面跳转、数据展示 | 接口调用链、数据持久化、状态流转 | 端到端业务正确性 |
| 数据隔离 | 不同角色登录后的可见性 | 跨租户/服务商数据不可见 | 数据安全隔离 |
| 金额计算 | 页面展示金额 | 后端计算逻辑、精度处理 | 金融级金额正确性 |
| 状态流转 | 状态标签更新、可用操作变化 | 状态机规则、权限控制 | 状态流转完整性 |
| 并发操作 | 操作冲突提示 | 乐观锁、幂等性 | 并发安全性 |
| 异常处理 | 错误提示展示、降级展示 | 错误码映射、事务回滚 | 异常场景健壮性 |
| 权限控制 | 菜单/按钮显示隐藏 | 接口权限校验 | 权限体系正确性 |

**⚠️ 必须停下等待用户确认测试范围，不允许跳过**

### 第3步：生成测试脚本

#### 前端 E2E 测试脚本（Playwright）

基于测试用例和页面原型，生成 Playwright 测试脚本：

**脚本存放路径**：`e2e/{domain}/{scenario-name}.spec.ts`

**编写规则**：
- 每个业务场景对应一个 `test.describe()` 块
- 每个测试用例对应一个 `test()` 块，用例名称与测试用例文档一致
- 操作步骤严格模拟真实用户行为
- 跨 Portal 场景通过 `loginAs(role, user)` 切换角色，切换时清除前一个角色的登录态和页面状态
- 选择器优先级：`data-testid` > `getByRole` > `getByLabel` > `getByText` > CSS 选择器
- 选择器来源：优先从页面原型中提取交互元素，如原型中无 `data-testid`，在脚本中标注 `// TODO: 需添加 data-testid`，由开发团队补充后回归
- 每个操作后添加必要的等待，避免竞态条件
- 断言覆盖：页面元素可见性、文本内容、URL 变化、API 请求发送、Toast/消息提示

#### 后端 API 验证脚本

对后端接口进行独立验证，补充前端 E2E 测试无法覆盖的场景：

**脚本存放路径**：`e2e/{domain}/{scenario-name}.api.spec.ts`

**验证内容**：
- 接口参数校验（必填缺失、格式错误、超长等）
- 业务规则校验（重复创建、状态冲突、金额边界等）
- 数据隔离验证（跨租户访问、Header 缺失等）
- 并发和幂等性验证
- 错误码映射验证

### 第4步：更新全量用例文档

根据本次增量变更，更新全量 E2E 测试用例文档：

1. 如 `docs/full-qa-testcases/{domain}.md` 不存在，则创建
2. 如已存在，根据增量变更进行更新：
   - **新增用例**：追加到对应业务场景的用例表中
   - **修改用例**：更新对应用例编号的内容
   - **废弃用例**：移除废弃的 E2E 测试用例
3. 更新后的全量文档必须保持用例编号的连续性和一致性

### 第5步：执行测试并收集结果

1. 执行 E2E 测试：
   ```bash
   npx playwright test e2e/{domain}/ --reporter=html,json
   ```

2. 收集测试结果：
   - 通过/失败/阻塞的用例数
   - 失败用例的截图和错误信息
   - 每个用例的执行时间

3. 对失败用例进行分析分类：
   - **脚本问题**：选择器失效、时序问题、数据问题
   - **环境问题**：服务不可用、配置错误、数据未初始化
   - **真实 Bug**：系统功能确实存在缺陷

**⚠️ 必须停下等待用户审阅测试结果，不允许跳过**

### 第6步：修复与回归

根据用户反馈和测试结果：

1. **脚本问题**：修复测试脚本，重新执行
2. **环境问题**：修复环境配置，重新执行
3. **真实 Bug**：记录到测试报告的缺陷清单中，由开发团队修复后重新验收
4. 修复后重新执行失败的用例：
   ```bash
   npx playwright test --last-failed
   ```
5. 循环修复直到所有非 Bug 类失败用例通过

**⚠️ 必须停下等待用户确认测试结果，不允许跳过**

### 第7步：生成验收报告

在任务目录下生成验收报告，文件路径：`docs/{domain}/{jira}-{summary}/{jira}-qa-report-{summary}.md`

**报告内容**：

| 章节 | 说明 |
|------|------|
| 验收概要 | JIRA 单号、需求简述、验收环境、验收时间、验收人 |
| 测试范围 | 本次验收覆盖的业务场景清单 |
| 测试结果汇总 | 总用例数、通过数、失败数、阻塞数、通过率 |
| 场景测试详情 | 每个业务场景的测试结果（通过/失败/阻塞） |
| 缺陷清单 | 真实 Bug 列表（编号、场景、严重程度、描述、状态） |
| 验收结论 | 通过（可发布）/ 有条件通过（附遗留问题）/ 不通过（阻塞发布） |

**验收结论规则**：
- **通过**：所有用例通过，无 P0/P1 缺陷
- **有条件通过**：存在 P2 缺陷但不影响核心业务流程，需记录遗留问题并约定修复时间
- **不通过**：存在 P0/P1 缺陷或核心业务流程失败，阻塞发布

### 第8步：发送飞书群通知

调度 `ex-common-feishu-notify` 发送飞书群通知，使用**卡片消息**格式，通知内容：

| 字段 | 内容 |
|------|------|
| JIRA单号 | {jira} |
| 需求简述 | {需求简述} |
| 执行的Skill | 增量质量验收 |
| 开始时间 | {startTime} |
| 完成时间 | {endTime} |
| 执行人 | {owner} |
| 执行结果 | 通过/有条件通过/不通过（附通过率、P0/P1缺陷数） |

## 产出物

| 产出物 | 路径 | 说明 |
|--------|------|------|
| E2E 测试脚本 | `e2e/{domain}/{scenario-name}.spec.ts` | Playwright 测试脚本，可回归复用 |
| API 验证脚本 | `e2e/{domain}/{scenario-name}.api.spec.ts` | 后端接口验证脚本 |
| 增量 E2E 测试用例 | `docs/{domain}/{jira}-{summary}/{jira}-qa-testcases-{summary}.md` | 本次增量 E2E 测试用例 |
| 全量 E2E 测试用例 | `docs/full-qa-testcases/{domain}.md` | 全量 E2E 测试用例，增量累积 |
| 验收报告 | `docs/{domain}/{jira}-{summary}/{jira}-qa-report-{summary}.md` | 质量验收报告 |

## 注意事项

- 测试脚本中的选择器基于页面原型和运行时页面，不依赖源码
- 优先使用 `data-testid` 属性定位元素，如页面中未提供，在脚本中标注 `// TODO: 需添加 data-testid`
- 每个测试用例必须独立，不依赖其他用例的执行顺序或副作用
- 跨 Portal 角色切换时，必须清除前一个角色的登录态（Cookie、localStorage），避免角色串扰
- 涉及数据变更的测试（创建、编辑、删除），需要在 `beforeEach` 或 `afterEach` 中清理测试数据
- 网络请求使用 `page.waitForResponse()` 等待，避免硬编码 `page.waitForTimeout()`
- 金额相关断言必须验证精度，避免浮点数比较问题
- 测试报告中的失败用例必须区分"脚本问题"、"环境问题"和"真实 Bug"
- 验收报告的结论直接影响发布决策，必须客观准确

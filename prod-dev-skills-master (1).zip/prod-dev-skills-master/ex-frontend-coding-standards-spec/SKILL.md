---
name: ex-frontend-coding-standards-spec
description: 前端编码规范，定义 Vue SFC、TypeScript、CSS 的编码标准和最佳实践。此skill不由用户直接触发，由其他职责skill触发加载。
---

# 前端编码规范

## Vue SFC 规范

### `<script setup>` 代码顺序

1. 类型导入（`import type`）
2. 内部模块（API、composables、utils）
3. 页面私有子组件（通用/业务组件已通过 `unplugin-vue-components` 自动导入，无需手动引入）
4. Props / Emits 定义（`defineProps` / `defineEmits`）
5. 响应式状态（`ref`、`reactive`）
6. 计算属性（`computed`）
7. 方法（`function`）
8. 生命周期（`onMounted` 等）

> Vue 3 API（`ref`/`computed`/`onMounted` 等）、`useRouter`、`useRoute`、`defineStore`、`storeToRefs`、VueUse composables 已通过 auto-import 全局注入，无需手动 import。

### Props / Emits

使用 TypeScript 泛型语法，需要默认值时用 `withDefaults`：

```typescript
const props = withDefaults(defineProps<{ title: string; count?: number }>(), { count: 0 })

const emit = defineEmits<{
  change: [value: string]
  'update:modelValue': [value: string]
}>()
```

## TypeScript 规范

### 类型分三处管理

| 位置 | 用途 | 访问方式 |
|------|------|---------|
| `src/typings/api.d.ts` | 跨域共享基础类型（`PageParams`、`PageResult`、`Response`） | 全局可用，无需 import |
| `src/types/api/{domain}.ts` | 业务域 API 类型（`{Entity}Info`、`ListParams`、`CreateReq`） | 按需 import |
| `src/enums/appEnum.ts` | 枚举值 | 按需 import |

**规则：**
- 优先使用 `interface`，联合/映射类型用 `type`
- API 响应类型必须显式定义，禁止使用 `any`
- 禁止使用 `@ts-ignore`，确需跳过检查用 `@ts-expect-error` 并注明原因
- `typings/api.d.ts` 只放跨域共享基础结构，业务类型必须拆分到 `types/api/{domain}.ts`

### 异步函数模式

```typescript
async function fetchList() {
  loading.value = true
  try {
    const data = await getList(params)
    list.value = data.list
    total.value = data.total
  } catch {
    list.value = []
    total.value = 0
  } finally {
    loading.value = false
  }
}
```

## 响应式数据规范

- 统一使用 `ref`（包括对象和数组），禁止对 `reactive` 对象整体赋值
- 派生数据必须用 `computed`，禁止用 `watch` 手动同步
- `computed` 内禁止副作用（API 调用、DOM 操作）
- 避免 watch 链（A watch B，B watch C）

## 模板规范

- 切换频率低/条件复杂 → `v-if`；切换频率高 → `v-show`
- 列表渲染必须绑定 `:key="item.id"`
- 禁止在同一元素同时使用 `v-if` 和 `v-for`（先用 `computed` 过滤）
- 事件处理命名：`@click="handleSubmit"`、`@row-click="handleRowClick"`

## CSS 规范

- 所有组件必须使用 `<style scoped>` 或 CSS Modules，禁止写全局样式
- 需要穿透子组件样式时使用 `:deep()`
- 颜色、间距、字号、圆角统一使用 `src/assets/styles/variables.scss` 中定义的 CSS 变量（通过 Vite preprocessor 自动注入，组件内可直接使用）
- 组件库样式覆盖只允许在 `assets/styles/overrides/` 下编写

## 页面状态管理

每个数据请求页面必须处理四种状态：**Loading**（骨架屏/指示器）、**Empty**（空状态提示）、**Error**（提示 + 重试按钮）、**Success**（正常数据展示）。

API 错误由 axios 拦截器统一处理（网络错误/401/403/500 → 全局 toast 或跳转）；组件层只处理业务错误码和空数据场景。
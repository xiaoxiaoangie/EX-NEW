---
name: ex-product-changelog
description: 产品设计变更记录生成，基于设计流程的产出物自动生成结构化的 changelog 文档。记录页面原型变更、PRD 变更、业务规则变更等信息。此skill不由用户直接触发，由产品设计流程skill触发加载。
---

# 产品设计变更记录

基于设计流程的产出物，自动生成结构化的 changelog 文档。

## 输入

| 来源 | 说明 |
|------|------|
| 增量 PRD | `requirements/{jira}-{需求简述}/{jira}-prd-{需求简述}.md` |
| 全量 PRD | `designs/full-prd.md`（如有） |
| 页面原型 | `prototypes/*.html` |
| quality-metrics | 由设计流程传入，包含各阶段 AI 自动完成情况（如有） |

## 输出

文件：`requirements/{jira}-{需求简述}/{jira}-changelog-{需求简述}.md`，文档模板见 [changelog-template.md](references/changelog-template.md)。


## 生成规则

1. **自动收集**：从设计流程的产出物中提取变更信息
   - 增量 PRD → 业务规则变更、数据模型变更、权限变更
   - 页面原型 → 页面变更、交互逻辑变更
   - 全量 PRD 对比 → 变更内容识别

2. **变更识别**：
   - 新增页面：原型文件新增，PRD 中新增功能点
   - 修改页面：原型文件修改，PRD 中功能点变更
   - 业务规则：PRD 中业务规则章节的新增/修改/删除
   - 数据模型：PRD 中数据约束章节的字段变更

3. **分类归纳**：按变更类型（新增/修改/删除）分类

4. **省略空节**：如果某个变更类型没有内容，省略该节

5. **增量追加**：如果 changelog 文件已存在，追加新的变更记录而非覆盖

6. **质量指标**：
   - 当由设计流程传入 `quality-metrics` 时，根据各阶段数据填充质量指标表格
   - 如果 `quality-metrics` 未传入（独立调度时），省略质量指标章节

7. **审阅确认**：
   - 列出需要确认的角色清单
   - 便于后续跟踪审批进度

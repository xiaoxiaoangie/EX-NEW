---
name: ex-backend-code-review
description: 后端微服务代码审查规范，基于DDD分层架构、Spring Boot、MyBatis-Plus技术栈的全方位Code Review检查。覆盖DDD分层合规、编码规范、API设计、数据库设计、安全性、性能、异常处理和测试等维度。当需要进行代码审查、代码评审、代码质量检查时使用。触发场景：用户提到服务代码审查、服务code review。
---

# Code Review 流程

## 1. 审查准备

收到代码审查请求后，按以下步骤执行：

1. 确定审查范围（文件列表或变更内容）
2. 阅读相关设计文档（docs/designs/目录下的所有文档）
4. 读取本次任务的需求分析报告（`docs/requirements/{JIRA}-{需求简述}/{JIRA}-reqanalysis-{需求简述}.md`）：本任务的需求分析报告，包含功能需求、非功能需求、接口定义等
5. 触发通用术语规范 Skill（`ex-common-terminology-spec`），通用术语规范中规定的内容要作为评审标准
6. 触发编码规范 Skill（`ex-backend-coding-standards-spec`），编码规范中规定的内容要作为评审标准
7. 触发工程结构规范 Skill（`ex-backend-project-structure-spec`），工程结构规范中规定的内容要作为评审标准
8. 理解业务上下文和变更目的

## 2. 审查执行

按优先级从高到低依次检查以下维度，详细检查项见 [checklist.md](references/checklist.md)：

**P0 - 阻断级（必须修复）**
- 功能正确性：业务逻辑是否正确实现，边界条件是否处理
- 数据安全：是否存在SQL注入、敏感数据泄露、越权访问
- 数据一致性：事务边界是否正确，并发控制是否到位
- 数据隔离：所有数据操作是否在providerId维度隔离

**P1 - 严重级（强烈建议修复）**
- DDD分层合规：各层职责是否正确，依赖方向是否合规
- 异常处理：是否使用Error体系，异常信息是否包含业务标识
- API规范：HTTP方法、路径、响应格式是否符合规范
- 数据库规范：DDL管理、索引设计、查询优化

**P2 - 建议级（建议修复）**
- 编码风格：命名规范、Lombok使用、代码注释
- 性能优化：N+1查询、缓存策略、分页限制
- 可维护性：代码重复、方法长度、职责单一

## 3. 审查输出格式

对每个发现的问题，按以下格式输出：

```
### [P{级别}] {问题标题}

**文件**: `{文件路径}`
**行号**: L{起始行}-L{结束行}
**维度**: {审查维度}
**问题描述**: {具体问题说明}
**修复建议**: {如何修复}
**示例代码**（如适用）:
{修复后的代码}
```

## 4. 审查总结

审查完成后输出总结报告：

```
## Code Review 总结

**审查范围**: {文件数量}个文件
**发现问题**: P0: {n}个 | P1: {n}个 | P2: {n}个

### 问题分布
| 维度 | P0 | P1 | P2 |
|------|----|----|-----|
| ... | ... | ... | ... |

### 总体评价
{对代码质量的整体评价和改进方向}
```

## 5. 发送飞书群通知

调度 `ex-common-feishu-notify` 发送飞书群通知，使用**卡片消息**格式，通知内容：

| 字段 | 内容 |
|------|------|
| JIRA单号 | {JIRA} |
| 需求简述 | {需求简述} |
| 执行的Skill | 后端代码审查 |
| 执行时间 | {YYYY-MM-DD HH:mm} |
| 执行人 | {owner} |
| 执行结果 | 成功/失败（附P0/P1/P2统计） |

## 6. 各层审查要点速查

### Facade层
- 接口定义是否添加@FeignClient声明
- 路径声明在Facade而非Controller
- DTO命名：{Action}{Resource}Request/Response
- DTO使用Bean Validation声明校验规则
- 不依赖任何其他层

### Web层（Controller）
- 实现Facade的interface
- 不包含业务逻辑
- 从TenantContextHolder获取providerId/userId
- DTO与领域对象的转换仅在此层完成

### App层
- 编排业务流程，不做业务规则判断
- 不直接调用Repository
- 不定义和引入DTO
- 事务注解@Transactional在此层声明

### Domain层
- 聚合根行为方法表达明确业务语义
- 使用Factory创建领域对象，禁止静态创建方法
- 业务规则校验在领域对象或领域服务中
- 不依赖其他层，不引入DTO

### Infrastructure层
- 基于MyBatis-Plus实现，优先使用BaseMapper内置方法
- 禁止自定义SQL和XML mapper
- 修改对象时明确指定修改属性，禁止save方法
- 查询单个实体使用Optional
- PO使用@Version乐观锁和@TableLogic逻辑删除


---
name: ex-common-feishu-notify
description: 发送飞书通知到个人账号或群聊。群通知通过 webhook 发送，个人通知通过邮箱发送。支持文本、富文本、卡片三种消息类型。触发场景：用户提到发送飞书通知、飞书消息、通知用户、发送通知。
---

# 发送飞书通知

通过飞书开放平台 API 发送消息，支持两种目标：

1. **群聊通知**：通过群机器人 webhook 发送
2. **个人通知**：通过用户邮箱查询 Open ID 后发送

## 消息类型

| 消息类型 | 说明 | 使用场景 |
| -------- | ---- | -------- |
| 文本消息 | 纯文本内容 | 简单通知、提醒 |
| 富文本消息 | 带格式的文本（标题 + 多段落） | 详细报告、多段落内容 |
| 卡片消息 | 结构化卡片（标题 + 内容模块） | 复杂信息展示、变更摘要 |

所有消息编码统一使用 **UTF-8**，`Content-Type` 必须包含 `charset=utf-8`。

## 执行流程

### 第 1 步：确认通知目标

- **群聊通知**：用户提供群名称或直接使用默认 webhook
- **个人通知**：用户提供邮箱地址（如 xxx@ipaylinks.com）

### 第 2 步：确认消息类型和内容

根据调用方传入的信息确认：
- 消息类型：文本 / 富文本 / 卡片
- 消息内容：由调用方传入（如 changelog 摘要、任务完成通知等）

### 第 3 步：发送消息

根据目标类型执行不同的发送流程：

- **群聊通知** → 执行「群聊发送流程」
- **个人通知** → 执行「个人发送流程」

### 第 4 步：返回发送结果

- 成功：返回消息发送确认
- 失败：根据错误码给出排查建议（见错误处理章节）

---

## 群聊发送流程

通过群机器人 webhook 发送，无需获取访问凭证。

### Webhook 地址

`https://open.feishu.cn/open-apis/bot/v2/hook/a988a967-6714-4663-a25a-f8f8136b6982`

### 发送文本消息

```
POST https://open.feishu.cn/open-apis/bot/v2/hook/a988a967-6714-4663-a25a-f8f8136b6982
Content-Type: application/json; charset=utf-8

{
  "msg_type": "text",
  "content": {
    "text": "{消息内容}"
  }
}
```

### 发送富文本消息

```
POST https://open.feishu.cn/open-apis/bot/v2/hook/a988a967-6714-4663-a25a-f8f8136b6982
Content-Type: application/json; charset=utf-8

{
  "msg_type": "post",
  "content": {
    "zh_cn": {
      "title": "{标题}",
      "content": [
        [{ "tag": "text", "text": "{第一段内容}" }],
        [{ "tag": "text", "text": "{第二段内容}" }]
      ]
    }
  }
}
```

富文本 content 为二维数组，每个一维数组代表一个段落，段落内可包含多个文本元素。

### 发送卡片消息

卡片消息使用 `lark_md` 格式排版，支持加粗、换行、列表、链接等。

```
POST https://open.feishu.cn/open-apis/bot/v2/hook/a988a967-6714-4663-a25a-f8f8136b6982
Content-Type: application/json; charset=utf-8

{
  "msg_type": "interactive",
  "card": {
    "config": {
      "wide_screen_mode": true
    },
    "header": {
      "template": "blue",
      "title": {
        "content": "{卡片标题}",
        "tag": "plain_text"
      }
    },
    "elements": [
      {
        "tag": "div",
        "text": {
          "content": "**变更简述**：{简述内容}\n**负责人**：{owner}",
          "tag": "lark_md"
        }
      },
      {
        "tag": "hr"
      },
      {
        "tag": "div",
        "text": {
          "content": "**变更详情**\n- 新增页面：{页面1}、{页面2}\n- 修改页面：{页面3}\n- 关键规则变更：{规则描述}",
          "tag": "lark_md"
        }
      },
      {
        "tag": "hr"
      },
      {
        "tag": "div",
        "fields": [
          {
            "is_short": true,
            "text": {
              "content": "**JIRA 单号**\n{JIRA}",
              "tag": "lark_md"
            }
          },
          {
            "is_short": true,
            "text": {
              "content": "**AI 完成率**\n{百分比}",
              "tag": "lark_md"
            }
          }
        ]
      }
    ]
  }
}
```

**lark_md 排版语法**：

| 语法 | 效果 | 示例 |
| ---- | ---- | ---- |
| `**文本**` | 加粗 | `**变更简述**` |
| `\n` | 换行 | `第一行\n第二行` |
| `- 文本` | 无序列表 | `- 新增页面：A、B` |
| `[文本](url)` | 超链接 | `[查看详情](https://...)` |
| `<at id={open_id}>` | @某人 | `<at id=ou_xxx>张三</at>` |

**卡片结构说明**：
- `header`：卡片标题栏，`template` 控制颜色主题
- `elements`：卡片内容区，按数组顺序从上到下排列
- `tag: "div"`：文本块，`content` 使用 lark_md 格式
- `tag: "hr"`：分割线，用于分隔不同内容区域
- `tag: "div" + fields`：并排字段，`is_short: true` 表示一行放两个字段

---

## 个人发送流程

通过用户邮箱查询 Open ID，再调用消息发送 API。

### 第 1 步：获取访问凭证

```
POST https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal
Content-Type: application/json; charset=utf-8

{
  "app_id": "cli_a9d675a0323b5bd6",
  "app_secret": "tXihCQ4Tx9i9JhLGOaowXbyP21ZktThW"
}
```

响应中的 `tenant_access_token` 有效期为 2 小时。

### 第 2 步：通过邮箱获取 Open ID

```
POST https://open.feishu.cn/open-apis/contact/v3/users/batch_get_id
Authorization: Bearer {tenant_access_token}
Content-Type: application/json; charset=utf-8

{
  "emails": ["{邮箱地址}"]
}
```

响应示例：

```json
{
  "code": 0,
  "data": {
    "user_list": [
      {
        "email": "user@ipaylinks.com",
        "user_id": "ou_xxxxxx"
      }
    ]
  }
}
```

所需权限：应用需开通 `contact:user.id:readonly` 权限。

### 第 3 步：发送消息

所有个人消息使用统一 API，通过 `msg_type` 区分消息类型：

```
POST https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id
Authorization: Bearer {tenant_access_token}
Content-Type: application/json; charset=utf-8

{
  "receive_id": "{open_id}",
  "msg_type": "{消息类型}",
  "content": "{消息内容JSON字符串}"
}
```

**发送文本消息**（msg_type = text）：

```json
{
  "receive_id": "{open_id}",
  "msg_type": "text",
  "content": "{\"text\":\"{消息内容}\"}"
}
```

**发送富文本消息**（msg_type = post）：

```json
{
  "receive_id": "{open_id}",
  "msg_type": "post",
  "content": "{\"zh_cn\":{\"title\":\"{标题}\",\"content\":[[{\"tag\":\"text\",\"text\":\"{内容}\"}]]}}"
}
```

**发送卡片消息**（msg_type = interactive）：

```json
{
  "receive_id": "{open_id}",
  "msg_type": "interactive",
  "content": "{\"config\":{\"wide_screen_mode\":true},\"header\":{\"template\":\"blue\",\"title\":{\"content\":\"{标题}\",\"tag\":\"plain_text\"}},\"elements\":[{\"tag\":\"div\",\"text\":{\"content\":\"{内容}\",\"tag\":\"lark_md\"}}]}"
}
```

---

## PowerShell 发送示例

所有请求统一使用 UTF-8 编码，通过 `[System.Text.Encoding]::UTF8.GetBytes()` 确保中文正确传输。

### 群聊 webhook 发送

```powershell
$headers = @{ "Content-Type" = "application/json; charset=utf-8" }
$body = [System.Text.Encoding]::UTF8.GetBytes('{"msg_type":"text","content":{"text":"中文消息内容"}}')
Invoke-RestMethod -Uri "https://open.feishu.cn/open-apis/bot/v2/hook/a988a967-6714-4663-a25a-f8f8136b6982" -Method Post -Headers $headers -Body $body
```

### 个人消息发送

```powershell
# 1. 获取 token
$tokenBody = [System.Text.Encoding]::UTF8.GetBytes('{"app_id":"cli_a9d675a0323b5bd6","app_secret":"tXihCQ4Tx9i9JhLGOaowXbyP21ZktThW"}')
$tokenResp = Invoke-RestMethod -Uri "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" -Method Post -Headers @{"Content-Type"="application/json; charset=utf-8"} -Body $tokenBody
$token = $tokenResp.tenant_access_token

# 2. 通过邮箱获取 Open ID
$idBody = [System.Text.Encoding]::UTF8.GetBytes('{"emails":["user@ipaylinks.com"]}')
$idResp = Invoke-RestMethod -Uri "https://open.feishu.cn/open-apis/contact/v3/users/batch_get_id" -Method Post -Headers @{"Authorization"="Bearer $token";"Content-Type"="application/json; charset=utf-8"} -Body $idBody
$openId = $idResp.data.user_list[0].user_id

# 3. 发送消息
$msgHeaders = @{
    "Authorization" = "Bearer $token"
    "Content-Type" = "application/json; charset=utf-8"
}
$msgBody = [System.Text.Encoding]::UTF8.GetBytes("{\"receive_id\":\"$openId\",\"msg_type\":\"text\",\"content\":\"{\\\"text\\\":\\\"中文消息内容\\\"}\"}")
Invoke-RestMethod -Uri "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id" -Method Post -Headers $msgHeaders -Body $msgBody
```

---

## 错误处理

| 错误码 | 含义 | 处理方式 |
| ------ | ---- | -------- |
| 400 | 参数错误 | 检查消息 JSON 格式是否正确 |
| 403 | 权限不足 | 检查应用权限配置（个人通知需 `contact:user.id:readonly`） |
| 404 | 用户/资源不存在 | 确认邮箱地址是否正确 |
| 429 | 频率限制 | 等待 1 秒后重试，最多重试 3 次 |
| 网络超时 | 请求超时 | 重试 1 次，仍失败则报告错误 |

## 注意事项

1. **UTF-8 编码**：所有请求必须使用 UTF-8 编码，`Content-Type` 必须包含 `charset=utf-8`，否则中文内容会显示乱码
2. **消息频率限制**：
   - 群机器人 webhook：每分钟最多 20 条
   - 个人消息：同一用户每分钟最多 60 条
3. **消息内容限制**：文本消息最多 30KB，富文本和卡片消息最多 100KB
4. **安全性**：webhook URL 和 app_secret 需妥善保管，使用 HTTPS 加密传输

---
name: ex-frontend-test-analysis
description: 前端测试分析规范，指导从页面需求、组件设计和接口定义生成测试用例。包括测试用例设计方法、覆盖策略、交互场景测试和测试文档生成。当需要进行前端测试分析、生成前端测试用例、编写前端测试文档时使用。触发场景：用户提到前端测试分析。
---

# 前端测试分析规范

本 skill 聚焦于前端测试用例的分析设计方法和测试文档生成。

## 分析流程

### 第1步：触发规范 Skill 并识别测试对象

1. 触发技术栈规范 Skill（`ex-frontend-tech-stack-spec`）
2. 触发工程结构规范 Skill（`ex-frontend-project-structure-spec`）
3. 触发通用术语规范 Skill（`ex-common-terminology-spec`）
2. 从任务拆解文档、技术方案文档和页面代码中提取：
   - 所有页面组件及其路由
   - 通用组件和业务组件的 Props / Emits 接口
   - 组合式函数（composables）的输入输出
   - API 模块的请求函数
   - 工具函数（utils）
   - Store 的 state / getters / actions
   - 交互行为和用户操作流程

### 第2步：设计测试用例

按测试层级分别设计用例：

#### 组件测试（Vitest + @vue/test-utils）

##### 页面组件
- 初始渲染：loading 状态、数据加载后的正常展示、空数据状态、错误状态
- 用户交互：按钮点击、表单提交、筛选操作、分页切换
- 路由参数：不同路由参数下的渲染结果
- 权限控制：有/无权限时的 UI 差异

##### 通用组件 / 业务组件
- Props 渲染：不同 props 组合下的渲染结果
- 默认值：未传 props 时使用默认值
- Emits 触发：用户操作触发正确的事件和参数
- 插槽：默认插槽和具名插槽的渲染
- 边界值：空数组、超长文本、特殊字符

##### Composables
- 返回值：初始状态正确
- 状态变更：调用方法后状态正确更新
- 副作用清理：组件卸载后清理定时器、事件监听等
- 错误处理：异常情况下的降级行为

#### API 模块测试（Vitest + MSW/Mock）
- 请求参数：正确拼装 URL、query、body
- 响应处理：正常响应的数据解包
- 错误处理：网络错误、业务错误码的处理

#### 工具函数测试（Vitest）
- 正常输入：预期输出
- 边界值：空值、null、undefined
- 异常输入：类型错误、格式错误

#### Store 测试（Vitest + Pinia Testing）
- 初始状态：state 默认值正确
- Actions：调用后 state 正确更新
- Getters：派生数据计算正确

#### E2E 测试（Playwright）
- 关键用户流程：完整的操作路径（如列表→筛选→详情→编辑→保存）
- 页面导航：路由跳转正确
- 表单流程：填写→校验→提交→反馈

### 第3步：生成测试用例文档

全量测试用例文档输出到 `docs/{domain}/designs/full-testcases.md`。
增量测试用例文档输出到任务目录 `docs/{domain}/requirements/{jira}-{变更简述}/`。

#### 3.1 增量测试用例文档（本次变更）

每次需求变更或新功能开发时，生成本次相关的增量测试用例文档，仅包含本次变更涉及的测试用例。

**文件路径**：`docs/{domain}/requirements/{jira}-{变更简述}/`，文件名：{jira}-testcase-{变更简述}.md，文档模板见 [testcase-template.md](references/testcase-template.md)。

#### 3.2 全量测试用例文档（回归测试）

在生成增量文档的同时，**必须同步更新**全量测试用例文档。全量文档包含所有页面和组件的完整测试用例，用于回归测试。

**文件路径**：`docs/{domain}/designs/full-testcases.md`，文档模板见 [testcase-template.md](references/testcase-template.md)。

**更新规则**：
1. 如果全量文档不存在，则创建完整的全量测试用例文档
2. 如果全量文档已存在，则根据本次增量变更进行更新：
   - **新增用例**：将增量文档中的新增测试用例追加到对应页面/组件的测试用例表中
   - **修改用例**：更新全量文档中对应用例编号的内容
   - **废弃用例**：从全量文档中移除废弃的测试用例
3. 更新后的全量文档必须保持用例编号的连续性和一致性


### 第4步：发送飞书群通知

调度 `ex-common-feishu-notify` 发送飞书群通知，使用**卡片消息**格式，通知内容：

| 字段 | 内容 |
|------|------|
| JIRA单号 | {jira} |
| 需求简述 | {需求简述} |
| 执行的Skill | 前端测试分析 |
| 执行时间 | {YYYY-MM-DD HH:mm} |
| 执行人 | {owner} |
| 执行结果 | 成功/失败（附用例数） |

## 测试用例设计原则

### 覆盖策略
- 每个页面组件至少覆盖4种状态：loading、empty、error、success
- 每个通用/业务组件的每个 prop 至少1个用例
- 每个 emit 事件至少1个触发用例
- 每个 composable 的每个返回值至少1个用例
- 每个工具函数至少1个正常用例 + 1个边界用例
- 关键用户流程必须有 E2E 用例覆盖

### 预期结果规范
- 组件测试：验证 DOM 结构、文本内容、CSS 类名、事件触发
- 单元测试：验证返回值、状态变更、副作用
- E2E 测试：验证页面跳转、数据展示、操作反馈

### 用例编号规范
- 格式：`TC-{模块序号}{用例序号}`
- 页面组件：TC-01xx、TC-02xx（按页面顺序）
- 通用组件：TC-C0xx
- Composables：TC-H0xx
- Store：TC-S0xx
- Utils：TC-U0xx
- E2E：TC-E0xx
- 全量文档和增量文档使用相同的编号体系，确保一致性

### 测试分层覆盖
| 层 | 工具 | 测试重点 | Mock 对象 | 执行阶段 |
|---|---|---|---|---|
| 组件 | Vitest + @vue/test-utils | 渲染、交互、Props/Emits | API 模块、Router、Store | 开发流程 |
| 单元 | Vitest | 纯逻辑、数据转换 | 无（纯函数）或最小依赖 | 开发流程 |
| E2E | Playwright | 完整用户流程、页面导航 | 后端 API（可选 Mock Server） | QA验收（`ex-qa-incremental`） |
